// Package main initializes the project and runs the query
package main

import (
	"context"
	"fmt"
	"path/filepath"
	"sync"
	"time"

	apicalls "github.com/xaaha/hulak/pkg/apiCalls"
	"github.com/xaaha/hulak/pkg/envparser"
	"github.com/xaaha/hulak/pkg/features"
	userflags "github.com/xaaha/hulak/pkg/userFlags"
	"github.com/xaaha/hulak/pkg/utils"
	"github.com/xaaha/hulak/pkg/yamlparser"
)

/*
InitializeProject starts the project by creating envfolder and global.env file in it.
*/
func InitializeProject(env string, isCli bool) map[string]any {
	if err := envparser.CreateDefaultEnvs(nil); err != nil {
		utils.PanicRedAndExit("%v", err)
	}
	envMap, err := envparser.GenerateSecretsMap(env, isCli)
	if err != nil {
		panic(err)
	}
	return envMap
}

// runTasks manages the go tasks with a limited worker pool
func runTasks(filePathList []string, secretsMap map[string]any, debug bool, fp string) {
	// Configuration parameters
	maxWorkers := utils.GetWorkers(nil) // Dynamically determine worker count
	maxRetries := 3                     // Number of retries for failed tasks
	timeout := 60 * time.Second         // Timeout for each API call

	if fp != "" {
		// If fp flag has a path, then let's not retry it again
		maxRetries = 1
	}

	var wg sync.WaitGroup
	taskChan := make(chan string, len(filePathList)) // Buffered channel for tasks

	// Fill the task channel with file paths
	for _, path := range filePathList {
		taskChan <- path
	}
	close(taskChan)

	// Create a pool of worker goroutines
	for i := range maxWorkers {
		wg.Add(1)
		go func(_ int) {
			defer wg.Done()

			for path := range taskChan {
				// Process each task with retry logic
				success := false
				var lastErr error

				for attempt := 0; attempt < maxRetries && !success; attempt++ {
					if attempt > 0 {
						// Exponential backoff for retries
						backoffDuration := time.Duration(1<<(attempt-1)) * time.Second
						utils.PrintWarning(fmt.Sprintf("Retrying %s (attempt %d/%d) after %v",
							path, attempt+1, maxRetries, backoffDuration))
						time.Sleep(backoffDuration)
					}

					// Create a context with timeout
					ctx, cancel := context.WithTimeout(context.Background(), timeout)

					// Use a channel to handle the task completion
					doneChan := make(chan struct{})
					errChan := make(chan error, 1)

					// Execute the task in a separate goroutine
					go func() {
						err := processTask(path, utils.CopyEnvMap(secretsMap), debug)
						if err != nil {
							errChan <- err
						} else {
							close(doneChan)
						}
					}()

					// Wait for either completion, error, or timeout
					select {
					case <-doneChan:
						success = true
						utils.PrintInfo(fmt.Sprintf("Processed '%s'", filepath.Base(path)))
					case err := <-errChan:
						lastErr = err
						utils.PrintInfo(fmt.Sprintf("(attempt %d/%d)", attempt+1, maxRetries))
					case <-ctx.Done():
						lastErr = fmt.Errorf("timeout after %v", timeout)
						utils.PrintRed(fmt.Sprintf("Timeout processing %s after %v (attempt %d/%d)",
							path, timeout, attempt+1, maxRetries))
					}
					// Always cancel the context created with timeout
					cancel()
				}

				if !success {
					utils.PrintRed(fmt.Sprintf("Failed to process %s after %d attempts: %v",
						path, maxRetries, lastErr))
				}
			}
		}(i)
	}
	// Wait for all workers to finish
	wg.Wait()
}

// processTask handles a single task, separated to simplify the worker logic
func processTask(path string, secretsMap map[string]any, debug bool) error {
	// Parse the configuration for the file
	config, err := yamlparser.ParseConfig(path, secretsMap)
	if err != nil {
		errMsg := fmt.Sprintf("failed to parse config %v", err)
		return utils.ColorError(errMsg)
	}

	// Handle different kinds based on the yaml 'kind' we get
	switch {
	case config.IsAuth():
		return features.SendAPIRequestForAuth2(secretsMap, path, debug)
	case (config.IsAPI() || config.IsGraphql()):
		return apicalls.SendAndSaveAPIRequest(secretsMap, path, debug)
	default:
		return fmt.Errorf("unsupported kind in file: %s", path)
	}
}

/*
 things we could optiize for but is probably too much here
 Rate limiting an API.
 Priority Queues: For mixed task types with different priorities
 Result Collection: Add a results channel to collect success/failure statistics.
 Graceful Shutdown: Add signal handling to cancel in-progress tasks if the program is terminated.
*/

// DiscoverFilePaths collects all file paths from -f, -fp, -dir, and -dirseq flags.
// Returns three slices: files from -f/-fp, concurrent dir files, and sequential dir files.
func DiscoverFilePaths(
	fileName, fp, dir, dirseq string,
	hasDirFlags bool,
) (fileList, concurrentDir, sequentialDir []string) {
	if fp != "" || fileName != "" {
		var err error
		fileList, err = userflags.GenerateFilePathList(fileName, fp)
		if err != nil {
			if !hasDirFlags {
				utils.PanicRedAndExit("%v", err)
			}
			utils.PrintWarning(fmt.Sprintf("Warning with file flags: %v", err))
		}
	}

	if hasDirFlags {
		dirPaths, err := apicalls.ListDirPaths(dir, dirseq)
		if err != nil {
			utils.PrintRed(fmt.Sprintf("Error processing directories: %v", err))
		} else {
			concurrentDir = dirPaths.Concurrent
			sequentialDir = dirPaths.Sequential
		}
	}

	return fileList, concurrentDir, sequentialDir
}

// HandleAPIRequests processes API requests from pre-discovered file lists.
// concurrentFiles are processed via worker pool, sequentialFiles one-by-one.
func HandleAPIRequests(
	secrets map[string]any,
	debug bool,
	concurrentFiles []string,
	sequentialFiles []string,
	fp string,
) {
	if len(concurrentFiles) > 0 {
		if len(concurrentFiles) > 1 || len(sequentialFiles) > 0 {
			utils.PrintInfo(
				fmt.Sprintf("Processing %d files concurrently...", len(concurrentFiles)),
			)
		}
		runTasks(concurrentFiles, secrets, debug, fp)
	}
	if len(sequentialFiles) > 0 {
		utils.PrintInfo(fmt.Sprintf("Processing %d files sequentially...", len(sequentialFiles)))
		processFilesSequentially(sequentialFiles, secrets, debug)
	}

	totalFiles := len(concurrentFiles) + len(sequentialFiles)
	if totalFiles == 0 {
		utils.PrintWarning(
			"No files were processed. Please check your path or directory arguments.",
		)
	}
}

// processFilesSequentially handles files one by one in a sequential manner
func processFilesSequentially(filePaths []string, secretsMap map[string]any, debug bool) {
	for _, path := range filePaths {

		// Create a fresh copy of the environment for each file
		fileEnv := utils.CopyEnvMap(secretsMap)

		err := processTask(path, fileEnv, debug)
		utils.PrintInfo(fmt.Sprintf("Processed: '%s'", filepath.Base(path)))
		if err != nil {
			utils.PrintRed(fmt.Sprintf("Error processing %s: %v", path, err))
		}
	}
}
