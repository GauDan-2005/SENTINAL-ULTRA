# Environment Secrets

- Environment secrets files (for example `global.env`) live in the `env/` folder at the project root.
- The `env/` setup is required only for requests that use environment template vars like `{{.key}}`.
- If a selected request needs environment vars and `env/global.env` is missing, Hulak asks to initialize the project setup at runtime.
- Directory structure

```text
env/
  global.env
  prod.env
collection1/
  file1.yaml
  file2.yaml
  file3.yaml
collection2/
  file4.yml
  file5.yml
  file6.yml
```

- `<name>.env` file supports the following types:

  - `bool`,
  - `float64`,
  - `int`, and
  - `string`

  - To explicitly treat these values as a string, wrap the value in a double or single quote. For example,

```env
# Strings (quoted or unquoted)
graphqlUrl = "https://example.com/graphql"
baseUrl=https://example.com/
userName=xaaha
product = hulak

# Referencing another value
age={{.userAge}} # Referenced from below

# Numeric and boolean values
userAge = 18
userAgeAsString = "100.0"         # string
hasRunMarathon = false            # bool
hasRunMarathonAsString = "false"  # string
```

> [!Important]
> Since Hulak users go's template parsing under the hood, special characters besides underscore is not allowed in key.
> For example
>
> ```env
> "xaaha.userId" = "92n2a-2axaeix-9qnx9285x" ❌ Not allowed
> `user'sId` = "92n2a-2axaeix-9qnx9285x" ❌ Not allowed
> `client-id` = "92n2a-2axaeix-9qnx9285x" ❌ Not allowed
> # only underscores are allowed
> client_id = "92n2a-2axaeix-9qnx9285x" ✅ Allowed
> ```

- Use the secrets above

```yaml
body:
  graphql:
    query: |
      query Hello($name: String!, $age: Int) {
        hello(person: { name: $name, age: $age })
      }
    variables:
      name: "{{.userName}}"
      age: "{{.userAge}}" # userAge is int in this case.
```

> [!Tip]
> Since YAML does not support double curly braces ({{}}) without quotes, wrap values in backticks (`{{.key}}`), single quotes ('{{.key}}'), or double quotes ("{{.key}}"), to avoid issues.

## Flags

| Flag   | Description                                                                                                     | Usage       |
| ------ | --------------------------------------------------------------------------------------------------------------- | ----------- |
| `-env` | Specify the environment file you want to use for Api Call. If the user flag is absent, it defaults to `global`. | `-env prod` |

## Subcommands

| Subcommand | Description                                   | Usage                                             |
| ---------- | --------------------------------------------- | ------------------------------------------------- |
| migrate    | migrates postman environment files for hulak. | `migrate "path/to/file.json" "path/to/file2.json` |

You can provide path to all the files after migrate. `migrate` creates the file, if not present, and appends all the content.

> [!Note]
> During migration, if any secret's key has any special characters like '/', " ' " and so on, they will be removed. Dot (.) will be replaced with an underscore (\_).
