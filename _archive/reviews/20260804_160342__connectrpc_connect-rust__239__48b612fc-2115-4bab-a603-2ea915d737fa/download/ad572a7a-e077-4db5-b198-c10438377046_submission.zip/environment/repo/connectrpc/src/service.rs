//! Tower service integration for ConnectRPC.
//!
//! This module provides a [`tower::Service`] implementation that allows
//! ConnectRPC handlers to be integrated into existing web servers.
//!
//! # Example with hyper
//!
//! ```rust,ignore
//! use connectrpc::{Router, ConnectRpcService};
//! use std::sync::Arc;
//! // `register` is provided by the generated `<Service>Ext` extension trait:
//! use my_proto::greet::v1::GreetServiceExt;
//!
//! let router = Arc::new(MyGreetService).register(Router::new());
//! let service = ConnectRpcService::new(router);
//! // Use with hyper or any tower-compatible framework
//! ```
//!
//! # Example with axum (requires `axum` feature)
//!
//! ```rust,ignore
//! use axum::{Router, routing::get};
//! use connectrpc::Router as ConnectRouter;
//! use std::sync::Arc;
//!
//! let connect_router = Arc::new(MyGreetService).register(ConnectRouter::new());
//!
//! let app = Router::new()
//!     .route("/health", get(health_handler))
//!     .merge(connect_router.into_axum_router());
//! ```

use std::convert::Infallible;
use std::future::Future;
use std::ops::ControlFlow;
use std::pin::Pin;
use std::sync::Arc;
use std::task::Context as TaskContext;
use std::task::Poll;
use std::time::Duration;

use bytes::Bytes;
use bytes::BytesMut;
use futures::{Stream, StreamExt};
use http::Method;
use http::Request;
use http::Response;
use http::StatusCode;
use http::header;
use http_body::Body;
use http_body::Frame;
use http_body_util::BodyExt;
use http_body_util::Full;
use serde::Serialize;
use tokio_util::codec::Decoder as _;
use tracing::Instrument;

use crate::codec::CodecFormat;
use crate::codec::content_type;
use crate::codec::header as connect_header;
use crate::compression::CompressionPolicy;
use crate::compression::CompressionRegistry;
use crate::deadline::DeadlinePolicy;
use crate::dispatcher::Dispatcher;
use crate::envelope::Envelope;
use crate::envelope::EnvelopeDecoder;
use crate::error::ConnectError;
use crate::handler::BoxStream;
use crate::interceptor::{
    Interceptor, call_bidi_streaming_intercepted, call_client_streaming_intercepted,
    call_server_streaming_intercepted, call_unary_intercepted,
};
use crate::protocol::Protocol;
use crate::response::{EncodedResponse, RequestContext};
use crate::router::MethodKind;
use crate::router::Router;

// ============================================================================
// GET Request Query Parameter Handling
// ============================================================================

/// Parsed query parameters from a GET request.
///
/// According to the Connect protocol, GET requests encode the message and metadata
/// in query parameters instead of the request body.
#[derive(Debug, Default)]
struct GetQueryParams {
    /// The encoded message (percent-encoded or base64).
    message: Option<String>,
    /// The message encoding format ("proto" or "json").
    encoding: Option<String>,
    /// Whether the message is base64-encoded.
    base64: bool,
    /// The compression algorithm used on the message.
    compression: Option<String>,
    /// The Connect protocol version ("v1").
    connect_version: Option<String>,
}

/// Parse query parameters from a GET request URL.
///
/// Extracts the Connect-specific parameters: `message`, `encoding`, `base64`,
/// `compression`, and `connect`.
fn parse_get_query_params(query: Option<&str>) -> Result<GetQueryParams, ConnectError> {
    let Some(query) = query else {
        return Err(ConnectError::invalid_argument(
            "GET request requires query parameters",
        ));
    };

    let mut params = GetQueryParams::default();

    for pair in query.split('&') {
        let mut parts = pair.splitn(2, '=');
        let key = parts.next().unwrap_or("");
        let value = parts.next().unwrap_or("");

        match key {
            "message" => params.message = Some(value.to_owned()),
            "encoding" => params.encoding = Some(value.to_owned()),
            "base64" => params.base64 = value == "1",
            "compression" => params.compression = Some(value.to_owned()),
            "connect" => params.connect_version = Some(value.to_owned()),
            _ => {} // Ignore unknown parameters per spec
        }
    }

    // Encoding is required
    if params.encoding.is_none() {
        return Err(ConnectError::invalid_argument(
            "GET request requires 'encoding' query parameter",
        ));
    }

    Ok(params)
}

// ============================================================================
// Request Metadata Extraction
// ============================================================================

/// Metadata extracted from request headers.
///
/// This struct captures the common headers needed by both unary and streaming
/// handlers, avoiding duplication of header extraction logic.
#[derive(Debug)]
struct RequestMetadata {
    /// The Content-Type header value.
    content_type: Option<String>,
    /// The detected protocol. Used for protocol-specific behavior in handlers.
    #[allow(dead_code)]
    protocol: Protocol,
    /// The timeout parsed from the protocol's timeout header.
    timeout: Option<Duration>,
    /// Compression encoding for unary requests (from Content-Encoding header).
    unary_encoding: Option<String>,
    /// Compression encoding for streaming requests (protocol-specific header).
    streaming_encoding: Option<String>,
    /// Client's accepted encodings for unary responses (from Accept-Encoding header).
    unary_accept_encoding: Option<String>,
    /// Client's accepted encodings for streaming responses (protocol-specific header).
    streaming_accept_encoding: Option<String>,
    /// The Connect protocol version from connect-protocol-version header.
    /// Only meaningful for the Connect protocol.
    protocol_version: Option<String>,
    /// The original request headers (for passing to handlers).
    headers: http::HeaderMap,
}

impl RequestMetadata {
    /// Extract metadata from request headers, using the detected protocol to
    /// determine which header names to read.
    fn from_headers(headers: &http::HeaderMap, protocol: Protocol) -> Self {
        let content_type = headers
            .get(header::CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_owned());

        let timeout = headers
            .get(protocol.timeout_header())
            .and_then(|v| v.to_str().ok())
            .and_then(|s| parse_timeout(s, protocol));

        let unary_encoding = headers
            .get(header::CONTENT_ENCODING)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_owned());

        let streaming_encoding = headers
            .get(protocol.content_encoding_header())
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_owned());

        let unary_accept_encoding = headers
            .get(header::ACCEPT_ENCODING)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_owned());

        let streaming_accept_encoding = headers
            .get(protocol.accept_encoding_header())
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_owned());

        let protocol_version = headers
            .get(connect_header::PROTOCOL_VERSION)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_owned());

        Self {
            content_type,
            protocol,
            timeout,
            unary_encoding,
            streaming_encoding,
            unary_accept_encoding,
            streaming_accept_encoding,
            protocol_version,
            headers: headers.clone(),
        }
    }
}

/// Parse a timeout value according to the protocol's format.
///
/// - Connect: value is milliseconds (e.g., "5000")
/// - gRPC/gRPC-Web: value is digits + unit suffix (e.g., "5000m", "5S", "1H")
///   Units: H (hours), M (minutes), S (seconds), m (milliseconds),
///   u (microseconds), n (nanoseconds)
fn parse_timeout(s: &str, protocol: Protocol) -> Option<Duration> {
    match protocol {
        Protocol::Connect => {
            // Connect spec: "positive integer as ASCII string of at most 10
            // digits" (max 9_999_999_999 ms ≈ 115 days). Enforcing this bound
            // also guarantees `Instant::now() + d` cannot overflow.
            if s.is_empty() || s.len() > 10 {
                return None;
            }
            let ms = s.parse::<u64>().ok()?;
            Some(Duration::from_millis(ms))
        }
        Protocol::Grpc | Protocol::GrpcWeb => {
            // gRPC spec: value is at most 8 ASCII digits + single ASCII unit.
            // Reject non-ASCII early to avoid a char-boundary panic in split_at
            // (HeaderValue::to_str() already filters this, but this function
            // must be safe for any &str it is given).
            if s.is_empty() || !s.is_ascii() {
                return None;
            }
            let (digits, unit) = s.split_at(s.len() - 1);
            // Max 8 digits per spec → max 99_999_999 of any unit. Even at
            // hours (~11415 years) this is well within `Instant + Duration`
            // bounds. Rejecting over-length input prevents the overflow panic
            // that `Duration::from_secs(u64::MAX)` would trigger downstream.
            if digits.is_empty() || digits.len() > 8 {
                return None;
            }
            let value = digits.parse::<u64>().ok()?;
            match unit {
                "H" => value.checked_mul(3600).map(Duration::from_secs),
                "M" => value.checked_mul(60).map(Duration::from_secs),
                "S" => Some(Duration::from_secs(value)),
                "m" => Some(Duration::from_millis(value)),
                "u" => Some(Duration::from_micros(value)),
                "n" => Some(Duration::from_nanos(value)),
                _ => None,
            }
        }
    }
}

/// Collect a request body with an enforced on-wire size limit.
///
/// Wraps the body in `http_body_util::Limited` so that allocation is bounded
/// *before* collection completes — a malicious client cannot force unbounded
/// buffering by sending an oversized body. Returns `ResourceExhausted` if the
/// limit is exceeded, `Internal` for underlying body read errors.
///
/// **Trade-off:** On the limit-exceeded path, the body is NOT fully drained
/// before returning. For HTTP/1.1 this may disable keep-alive on that
/// connection (hyper's `poll_drain_or_close_read` race). This is deliberate:
/// draining an oversized body to preserve keep-alive would require reading
/// potentially gigabytes from a malicious client, defeating the limit. The
/// connection will close cleanly after the error response is sent.
async fn collect_body_limited<B>(body: B, limit: usize) -> Result<Bytes, ConnectError>
where
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::error::Error + Send + Sync + 'static,
{
    match http_body_util::Limited::new(body, limit).collect().await {
        Ok(collected) => Ok(collected.to_bytes()),
        Err(err) => {
            if err
                .downcast_ref::<http_body_util::LengthLimitError>()
                .is_some()
            {
                Err(ConnectError::resource_exhausted(format!(
                    "request body size exceeds limit {limit}"
                )))
            } else {
                Err(ConnectError::internal(format!(
                    "failed to read request body: {err}"
                )))
            }
        }
    }
}

/// Run a request future within an absolute server-side deadline.
///
/// Callers compute the deadline once after parsing headers so the same budget
/// covers body receipt and handler execution.
async fn with_request_deadline<F, T>(
    deadline: Option<std::time::Instant>,
    future: F,
) -> Result<T, ConnectError>
where
    F: Future<Output = Result<T, ConnectError>>,
{
    match deadline {
        Some(deadline) => tokio::time::timeout_at(tokio::time::Instant::from_std(deadline), future)
            .await
            .map_err(|_| ConnectError::deadline_exceeded("request timeout"))?,
        None => future.await,
    }
}

fn absolute_deadline(timeout: Option<Duration>) -> Option<std::time::Instant> {
    timeout.and_then(|t| std::time::Instant::now().checked_add(t))
}

fn deadline_from_headers(
    headers: &http::HeaderMap,
    protocol: Protocol,
    path: &str,
    deadline_policy: &DeadlinePolicy,
) -> Option<std::time::Instant> {
    let timeout = RequestMetadata::from_headers(headers, protocol).timeout;
    absolute_deadline(deadline_policy.moderate(timeout, path))
}

/// Decode the message from GET request query parameters.
///
/// The message may be:
/// - Percent-encoded UTF-8 (for JSON without compression)
/// - Base64-encoded (for binary proto or compressed data)
fn decode_get_message(
    params: &GetQueryParams,
    compression: &CompressionRegistry,
    max_message_size: usize,
) -> Result<Bytes, ConnectError> {
    let Some(ref encoded_message) = params.message else {
        // Empty message is valid (e.g., for requests with no fields)
        return Ok(Bytes::new());
    };

    // Decode the message based on base64 flag
    let decoded = if params.base64 {
        // Base64-decode (URL-safe alphabet, optional padding)
        use base64::Engine;
        use base64::engine::general_purpose::URL_SAFE_NO_PAD;

        // Handle both padded and unpadded base64
        let message = if encoded_message.contains('%') {
            // Percent-decode first (padding chars may be encoded)
            percent_decode(encoded_message)?
        } else {
            encoded_message.as_bytes().to_vec()
        };

        URL_SAFE_NO_PAD
            .decode(&message)
            .or_else(|_| {
                // Try with standard padding handling
                use base64::engine::general_purpose::URL_SAFE;
                URL_SAFE.decode(&message)
            })
            .map_err(|e| ConnectError::invalid_argument(format!("invalid base64 encoding: {e}")))?
    } else {
        // Percent-decode as UTF-8
        percent_decode(encoded_message)?
    };

    // Decompress if needed
    let body = if let Some(ref encoding) = params.compression {
        if encoding != "identity" {
            compression.decompress_with_limit(encoding, Bytes::from(decoded), max_message_size)?
        } else {
            Bytes::from(decoded)
        }
    } else {
        Bytes::from(decoded)
    };

    // Check message size limit (for uncompressed messages; compressed ones
    // are already bounded by decompress_with_limit)
    if body.len() > max_message_size {
        return Err(ConnectError::resource_exhausted(format!(
            "message size {} exceeds limit {}",
            body.len(),
            max_message_size
        )));
    }

    Ok(body)
}

/// Percent-decode a URL-encoded string.
///
/// Handles both standard percent-encoding (`%XX`) and the `+`-as-space
/// convention used in query strings.
fn percent_decode(input: &str) -> Result<Vec<u8>, ConnectError> {
    // Replace '+' with space first (query string convention), then
    // use the percent-encoding crate for the standard %XX decoding.
    let with_spaces = input.replace('+', " ");
    Ok(percent_encoding::percent_decode_str(&with_spaces).collect())
}

// ============================================================================
// Limits and Configuration
// ============================================================================

/// Default maximum request body size (4 MB).
///
/// This matches the default in tonic and grpc-go.
pub const DEFAULT_MAX_REQUEST_BODY_SIZE: usize = 4 * 1024 * 1024;

/// Default maximum message size (4 MB).
///
/// This limits the final (post-decompression) message size for both unary
/// and streaming RPCs. It also serves as the decompression limit, preventing
/// compression bomb attacks.
pub const DEFAULT_MAX_MESSAGE_SIZE: usize = 4 * 1024 * 1024;

/// Configuration limits for ConnectRPC requests.
///
/// These limits protect against denial-of-service attacks by bounding
/// memory usage for request processing.
///
/// # Relationship between limits
///
/// `max_request_body_size` bounds the total on-wire bytes read from the
/// network, while `max_message_size` bounds individual logical messages
/// after decompression.
///
/// For **unary RPCs**, the request body contains a single message (possibly
/// compressed). Set `max_request_body_size >= max_message_size` to allow
/// uncompressed messages up to the message limit. Compressed messages may
/// have a smaller on-wire body that expands up to `max_message_size`.
///
/// For **server streaming RPCs**, the request body still contains a single
/// envelope-framed message (only the response is streamed), so the same
/// guidance as unary applies — the body is read in full before processing.
///
/// For **client and bidirectional streaming RPCs**, messages are processed
/// incrementally from the body stream — the full body is never buffered.
/// In that case `max_request_body_size` does not apply, and
/// `max_message_size` is the primary per-message protection.
///
/// `element_memory_limit` is the odd one out, and the distinction from
/// `max_message_size` is the one worth getting right: `max_message_size`
/// bounds *decompressed bytes on the wire*, while `element_memory_limit`
/// bounds the *in-memory footprint of the element count* those bytes ask
/// for. A repeated field of empty messages costs two bytes each encoded and
/// a whole struct each decoded, so a body comfortably inside
/// `max_message_size` can still expand by orders of magnitude. Raising one
/// does not raise the other.
///
/// These are **server** limits, applied to received requests. A client
/// decoding responses currently uses buffa's defaults, with no equivalent
/// override.
#[derive(Debug, Clone)]
#[non_exhaustive]
pub struct Limits {
    /// Maximum size of the request body on the wire (before decompression).
    ///
    /// Applies to RPCs where the body is read in full (unary and server
    /// streaming). Should be at least `max_message_size` to allow
    /// uncompressed messages up to the message limit. Does not apply to
    /// client/bidi streaming where messages are processed incrementally.
    ///
    /// Default: 4 MB (matches tonic/grpc-go).
    pub max_request_body_size: usize,

    /// Maximum size of a single message after decompression.
    ///
    /// This applies uniformly to both unary and streaming RPCs, and to both
    /// compressed and uncompressed messages. Compressed payloads are bounded
    /// during decompression — the decompressor will never allocate more than
    /// this limit.
    ///
    /// Default: 4 MB.
    pub max_message_size: usize,

    /// Maximum memory a single decode may commit to repeated, map, string
    /// and bytes *elements*.
    ///
    /// This is an amplification defence, and it is charged on element
    /// footprint rather than on contents: a few bytes on the wire can ask
    /// the decoder to materialize a very large number of small elements,
    /// each with its own allocation overhead, while staying well under
    /// `max_message_size`. A single large payload is unaffected however big
    /// it grows, because its contents are not charged.
    ///
    /// Raise it for a trusted peer that legitimately sends messages with
    /// very many small elements; lower it to tighten the defence.
    ///
    /// Default: 32 MiB (buffa's `DEFAULT_ELEMENT_MEMORY_LIMIT`).
    pub element_memory_limit: usize,
}

impl Default for Limits {
    fn default() -> Self {
        Self {
            max_request_body_size: DEFAULT_MAX_REQUEST_BODY_SIZE,
            max_message_size: DEFAULT_MAX_MESSAGE_SIZE,
            element_memory_limit: buffa::DEFAULT_ELEMENT_MEMORY_LIMIT,
        }
    }
}

impl Limits {
    /// Create limits with no restrictions (unlimited).
    ///
    /// **Warning:** This disables DoS protection. Only use in trusted environments.
    pub fn unlimited() -> Self {
        Self {
            max_request_body_size: usize::MAX,
            max_message_size: usize::MAX,
            element_memory_limit: usize::MAX,
        }
    }

    /// Set the maximum request body size (on-wire, before decompression).
    ///
    /// Applies to unary and server streaming RPCs where the body is buffered.
    /// See [`Limits`] for details on the relationship between limits.
    #[must_use]
    pub fn max_request_body_size(mut self, size: usize) -> Self {
        self.max_request_body_size = size;
        self
    }

    /// Set the maximum message size (after decompression).
    ///
    /// This bounds individual messages in both unary and streaming RPCs.
    /// It also serves as the decompression limit.
    /// See [`Limits`] for details on the relationship between limits.
    #[must_use]
    pub fn max_message_size(mut self, size: usize) -> Self {
        self.max_message_size = size;
        self
    }

    /// Set the maximum memory a single decode may commit to repeated, map,
    /// string and bytes elements.
    ///
    /// See [`Limits`] for what this charges and why it is separate from
    /// `max_message_size`.
    #[must_use]
    pub fn element_memory_limit(mut self, bytes: usize) -> Self {
        self.element_memory_limit = bytes;
        self
    }

    /// The buffa decode options these limits imply.
    #[doc(hidden)] // read by generated dispatch via `RequestContext`
    #[must_use]
    pub fn decode_options(&self) -> buffa::DecodeOptions {
        buffa::DecodeOptions::new().with_element_memory_limit(self.element_memory_limit)
    }
}

// ============================================================================
// Streaming Response Types
// ============================================================================

/// End of stream message for streaming RPCs.
///
/// This is the final message in a streaming response, encoded as JSON
/// and sent with the END_STREAM flag (0x02) in the envelope.
#[derive(Debug, Clone, Serialize)]
struct EndStreamResponse {
    /// The error, if any (omit for success).
    #[serde(skip_serializing_if = "Option::is_none")]
    error: Option<EndStreamError>,
    /// Trailing metadata (optional).
    #[serde(skip_serializing_if = "Option::is_none")]
    metadata: Option<std::collections::HashMap<String, Vec<String>>>,
}

/// Error in the EndStreamResponse.
#[derive(Debug, Clone, Serialize)]
struct EndStreamError {
    code: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    message: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    details: Option<Vec<serde_json::Value>>,
}

impl EndStreamResponse {
    /// Convert trailers to metadata format, returning None if empty.
    fn metadata_from_trailers(
        trailers: &http::HeaderMap,
    ) -> Option<std::collections::HashMap<String, Vec<String>>> {
        if trailers.is_empty() {
            None
        } else {
            Some(headers_to_metadata(trailers))
        }
    }

    /// Create a successful end-stream response with no error.
    fn success(trailers: &http::HeaderMap) -> Self {
        Self {
            error: None,
            metadata: Self::metadata_from_trailers(trailers),
        }
    }

    /// Create an end-stream response with an error.
    ///
    /// Matches gRPC's `build_grpc_trailers` precedence: if the error carries
    /// its own trailers (via `ConnectError::with_trailers()`), those populate
    /// the metadata and the handler-context trailers are skipped to avoid
    /// duplication. Otherwise the handler's context trailers are used.
    fn error(err: &ConnectError, context_trailers: &http::HeaderMap) -> Self {
        let trailers_source = if err.trailers().is_empty() {
            context_trailers
        } else {
            err.trailers()
        };
        let metadata = Self::metadata_from_trailers(trailers_source);
        Self {
            error: Some(EndStreamError {
                code: err.code.as_str().to_owned(),
                message: err.message.clone(),
                details: if err.details.is_empty() {
                    None
                } else {
                    // Serialize via ErrorDetail's derive so all fields (type,
                    // value, debug) are included and the wire format stays in
                    // lockstep with unary error serialization.
                    Some(
                        err.details
                            .iter()
                            .filter_map(|d| serde_json::to_value(d).ok())
                            .collect(),
                    )
                },
            }),
            metadata,
        }
    }

    /// Encode this response to JSON bytes.
    fn to_json(&self) -> Bytes {
        // EndStreamResponse is always JSON, regardless of the message codec
        serde_json::to_vec(self)
            .map(Bytes::from)
            .unwrap_or_else(|_| Bytes::from_static(b"{}"))
    }
}

/// Create a streaming error response.
///
/// For streaming RPCs, errors should still return HTTP 200 with the error
/// encoded in an EndStreamResponse envelope. This function creates such a
/// response for errors that occur before the handler is invoked.
fn streaming_error_response(
    err: &ConnectError,
    protocol: Protocol,
    codec_format: CodecFormat,
) -> Response<StreamingResponseBody> {
    match protocol {
        Protocol::Connect => connect_streaming_error_response(err, codec_format),
        Protocol::Grpc | Protocol::GrpcWeb => grpc_error_response(err, protocol, codec_format),
    }
}

/// Build a Connect streaming error response with EndStreamResponse envelope.
fn connect_streaming_error_response(
    err: &ConnectError,
    codec_format: CodecFormat,
) -> Response<StreamingResponseBody> {
    use futures::stream::StreamExt as _;

    let end_stream = EndStreamResponse::error(err, err.trailers());
    let mut encoder = crate::envelope::EnvelopeEncoder::uncompressed();
    let mut buf = bytes::BytesMut::new();
    // encode_end_stream is infallible for uncompressed data
    let _ = encoder.encode_end_stream(end_stream.to_json(), &mut buf);
    let encoded = buf.freeze();

    // Create a simple stream that yields just the error envelope
    // Use .fuse() to make it safe to poll after returning None
    let body_stream = futures::stream::unfold(Some(encoded), async |data| {
        data.map(|bytes| (Ok(Frame::data(bytes)), None))
    })
    .fuse();

    let body = StreamingResponseBody {
        inner: Box::pin(body_stream),
        _reader_task: None,
    };

    let mut response = Response::builder().status(StatusCode::OK).header(
        header::CONTENT_TYPE,
        Protocol::Connect.response_content_type(codec_format, true),
    );

    for (key, value) in err.response_headers() {
        response = response.header(key, value);
    }

    response.body(body).unwrap_or_else(|_| {
        Response::new(StreamingResponseBody {
            inner: Box::pin(futures::stream::empty()),
            _reader_task: None,
        })
    })
}

/// Build a gRPC/gRPC-Web "trailers-only" error response.
///
/// For gRPC: HTTP 200 with grpc-status and grpc-message as HTTP/2 trailers
/// in a response with no data frames.
/// For gRPC-Web: same but trailers are encoded in the body.
fn grpc_error_response(
    err: &ConnectError,
    protocol: Protocol,
    codec_format: CodecFormat,
) -> Response<StreamingResponseBody> {
    let grpc_trailers = build_grpc_trailers(Some(err), err.trailers());

    let body_stream: Pin<Box<dyn Stream<Item = Result<Frame<Bytes>, Infallible>> + Send>> =
        match protocol {
            Protocol::Grpc => {
                // For gRPC: emit HTTP/2 trailers frame (no data)
                Box::pin(
                    futures::stream::once(async move { Ok(Frame::trailers(grpc_trailers)) }).fuse(),
                )
            }
            Protocol::GrpcWeb => {
                // For gRPC-Web: encode trailers as a body frame with flag 0x80
                let trailer_bytes = encode_grpc_web_trailers(&grpc_trailers);
                Box::pin(
                    futures::stream::once(async move { Ok(Frame::data(trailer_bytes)) }).fuse(),
                )
            }
            Protocol::Connect => unreachable!("Connect handled separately"),
        };

    let body = StreamingResponseBody {
        inner: body_stream,
        _reader_task: None,
    };

    let mut response = Response::builder().status(StatusCode::OK).header(
        header::CONTENT_TYPE,
        protocol.response_content_type(codec_format, true),
    );

    // For trailers-only gRPC responses, also include grpc-status in headers
    // so that clients can detect this as a trailers-only response
    if protocol == Protocol::Grpc {
        response = response.header(&GRPC_STATUS, err.code.grpc_code());
        if let Some(val) = err
            .message
            .as_deref()
            .and_then(|m| http::HeaderValue::from_str(&grpc_percent_encode(m)).ok())
        {
            response = response.header(&GRPC_MESSAGE, val);
        }
    }

    for (key, value) in err.response_headers() {
        response = response.header(key, value);
    }

    response.body(body).unwrap_or_else(|_| {
        Response::new(StreamingResponseBody {
            inner: Box::pin(futures::stream::empty()),
            _reader_task: None,
        })
    })
}

/// Encode gRPC trailers as a gRPC-Web trailer frame (flag byte 0x80).
///
/// The trailer frame body is HTTP/1-style headers: `key: value\r\n`.
fn encode_grpc_web_trailers(trailers: &http::HeaderMap) -> Bytes {
    let mut trailer_payload = Vec::new();
    for (key, value) in trailers.iter() {
        trailer_payload.extend_from_slice(key.as_str().as_bytes());
        trailer_payload.extend_from_slice(b": ");
        trailer_payload.extend_from_slice(value.as_bytes());
        trailer_payload.extend_from_slice(b"\r\n");
    }

    // Envelope: flag=0x80 (trailer), 4-byte big-endian length, payload
    let len = trailer_payload.len() as u32;
    let mut frame = Vec::with_capacity(5 + trailer_payload.len());
    frame.push(0x80); // trailer flag
    frame.extend_from_slice(&len.to_be_bytes());
    frame.extend_from_slice(&trailer_payload);
    Bytes::from(frame)
}

/// Convert headers to metadata format (keys -> list of values).
fn headers_to_metadata(
    headers: &http::HeaderMap,
) -> std::collections::HashMap<String, Vec<String>> {
    let mut metadata = std::collections::HashMap::new();
    for (key, value) in headers.iter() {
        let key_str = key.as_str().to_owned();
        let value_str = value.to_str().unwrap_or("").to_owned();
        metadata
            .entry(key_str)
            .or_insert_with(Vec::new)
            .push(value_str);
    }
    metadata
}

/// A streaming response body for server streaming RPCs.
///
/// This wraps a stream of encoded response bytes and handles envelope framing.
pub struct StreamingResponseBody {
    inner: Pin<Box<dyn Stream<Item = Result<Frame<Bytes>, Infallible>> + Send>>,
    /// Optional background reader task handle. The task is detached (not aborted)
    /// when the response body is dropped — it continues draining the request body
    /// until EOF or `MAX_DRAIN_BYTES`, which is critical for HTTP/1.1 keep-alive.
    /// Aborting the task early was found to cause a race where hyper's dispatcher
    /// sees the `Incoming` body dropped before EOF and closes the connection.
    _reader_task: Option<tokio::task::JoinHandle<()>>,
}

impl StreamingResponseBody {
    /// Create a new streaming response body from a stream of encoded messages.
    ///
    /// For Connect protocol, trailers are encoded as a JSON EndStreamResponse
    /// in the final envelope. For gRPC, trailers are sent as HTTP/2 trailing
    /// HEADERS frames.
    fn new(
        response_stream: BoxStream<Result<Bytes, ConnectError>>,
        trailers: http::HeaderMap,
        protocol: Protocol,
        compression: Option<(Arc<CompressionRegistry>, &'static str)>,
        compression_policy: CompressionPolicy,
    ) -> Self {
        let inner: Pin<Box<dyn Stream<Item = Result<Frame<Bytes>, Infallible>> + Send>> =
            match protocol {
                Protocol::Grpc => Box::pin(create_grpc_envelope_stream(
                    response_stream,
                    trailers,
                    compression,
                    compression_policy,
                )),
                Protocol::GrpcWeb => Box::pin(create_grpc_web_envelope_stream(
                    response_stream,
                    trailers,
                    compression,
                    compression_policy,
                )),
                Protocol::Connect => Box::pin(create_envelope_stream(
                    response_stream,
                    trailers,
                    compression,
                    compression_policy,
                )),
            };
        Self {
            inner,
            _reader_task: None,
        }
    }

    /// Attach the background reader-task handle returned by [`spawn_body_reader`].
    /// The handle is stored but never read or aborted — the task is owned by
    /// the runtime and runs to completion regardless of what happens to this
    /// `StreamingResponseBody`. The field exists to make the non-aborting
    /// policy explicit at the call site (see the `_reader_task` field comment
    /// for the HTTP/1.1 keep-alive race that motivated it). `task` is `None`
    /// on platforms without a joinable handle (see [`spawn_detached`]).
    fn with_reader_task(mut self, task: Option<tokio::task::JoinHandle<()>>) -> Self {
        self._reader_task = task;
        self
    }
}

impl Body for StreamingResponseBody {
    type Data = Bytes;
    type Error = Infallible;

    fn poll_frame(
        mut self: Pin<&mut Self>,
        cx: &mut TaskContext<'_>,
    ) -> Poll<Option<Result<Frame<Self::Data>, Self::Error>>> {
        self.inner.as_mut().poll_next(cx)
    }
}

/// Default threshold for flushing the accumulated envelope buffer to an
/// h2 DATA frame. 16 KiB matches h2's default `max_frame_size` — any larger
/// and hyper splits into multiple frames anyway, so there's no additional
/// batching benefit.
const STREAM_BATCH_THRESHOLD: usize = 16 * 1024;

/// How the stream terminates when the source is exhausted or errors.
///
/// Protocol-dependent: Connect sends an END_STREAM envelope with JSON
/// error/metadata; gRPC sends HTTP/2 trailers; gRPC-Web encodes trailers
/// as a 0x80-flagged body frame.
enum StreamFinalizer {
    /// Connect protocol: emit an END_STREAM-flagged envelope with JSON payload.
    ConnectEndStream,
    /// gRPC: emit HTTP/2 trailing HEADERS frame.
    GrpcTrailers,
    /// gRPC-Web: emit a DATA frame with the 0x80 flag and HTTP/1-style headers.
    GrpcWebTrailers,
}

impl StreamFinalizer {
    /// Build the terminal frame for a successful stream end.
    fn success(&self, trailers: &http::HeaderMap) -> Frame<Bytes> {
        match self {
            StreamFinalizer::ConnectEndStream => {
                let end_stream = EndStreamResponse::success(trailers);
                let mut buf = bytes::BytesMut::new();
                let mut enc = crate::envelope::EnvelopeEncoder::uncompressed();
                let _ = enc.encode_end_stream(end_stream.to_json(), &mut buf);
                Frame::data(buf.freeze())
            }
            StreamFinalizer::GrpcTrailers => Frame::trailers(build_grpc_trailers(None, trailers)),
            StreamFinalizer::GrpcWebTrailers => {
                let t = build_grpc_trailers(None, trailers);
                Frame::data(encode_grpc_web_trailers(&t))
            }
        }
    }

    /// Build the terminal frame for an error stream end.
    fn error(&self, err: &ConnectError, trailers: &http::HeaderMap) -> Frame<Bytes> {
        match self {
            StreamFinalizer::ConnectEndStream => {
                let end_stream = EndStreamResponse::error(err, trailers);
                let mut buf = bytes::BytesMut::new();
                let mut enc = crate::envelope::EnvelopeEncoder::uncompressed();
                let _ = enc.encode_end_stream(end_stream.to_json(), &mut buf);
                Frame::data(buf.freeze())
            }
            StreamFinalizer::GrpcTrailers => {
                Frame::trailers(build_grpc_trailers(Some(err), trailers))
            }
            StreamFinalizer::GrpcWebTrailers => {
                let t = build_grpc_trailers(Some(err), trailers);
                Frame::data(encode_grpc_web_trailers(&t))
            }
        }
    }
}

/// A `Stream<Item = Frame<Bytes>>` that batches source items into a single
/// h2 DATA frame per poll cycle.
///
/// The `poll_next` loop drains the source stream until it returns `Pending` or
/// `None`, accumulating encoded envelopes in `buf`. This means:
///
/// - A **synchronous producer** (e.g. `stream::iter` or `unfold` with no `.await`)
///   gets all items drained in one `poll_next` → one DATA frame → one h2 lock.
/// - An **async producer** (e.g. channel receiver, DB cursor) naturally yields
///   `Pending` between items → one flush per scheduler tick.
///
/// The 16 KiB threshold bounds memory for the pathological case (fast
/// synchronous producer with large items).
///
/// # Terminal state machine
///
/// At stream end (source returns `None` or `Err`), if `buf` is non-empty,
/// the data frame is emitted FIRST, and the finalizer frame is staged for
/// the next poll. This ensures partial batches aren't dropped.
struct BatchingEnvelopeStream {
    /// Source of encoded message bytes (already proto/JSON encoded).
    source: futures::stream::Fuse<BoxStream<Result<Bytes, ConnectError>>>,
    /// Accumulation buffer — envelopes are appended here until flush.
    buf: bytes::BytesMut,
    /// Envelope encoder — writes 5-byte header + optional compression.
    encoder: crate::envelope::EnvelopeEncoder,
    /// Context trailers carried through to the finalizer frame.
    trailers: http::HeaderMap,
    /// How to build the terminal frame.
    finalizer: StreamFinalizer,
    /// Finalizer frame staged for the next poll (when buf was non-empty at end).
    pending_final: Option<Frame<Bytes>>,
    /// Large payload (post-compression, when negotiated) staged for the next
    /// poll: emitted as its
    /// own data frame (refcount clone) right after the header flush, instead
    /// of being copied into `buf`. See [`EnvelopeEncoder::encode_chained`].
    ///
    /// [`EnvelopeEncoder::encode_chained`]: crate::envelope::EnvelopeEncoder::encode_chained
    pending_payload: Option<Bytes>,
    /// Fused-done flag.
    done: bool,
}

impl BatchingEnvelopeStream {
    fn new(
        source: BoxStream<Result<Bytes, ConnectError>>,
        trailers: http::HeaderMap,
        compression: Option<(Arc<CompressionRegistry>, &'static str)>,
        compression_policy: CompressionPolicy,
        finalizer: StreamFinalizer,
    ) -> Self {
        Self {
            source: source.fuse(),
            buf: bytes::BytesMut::new(),
            encoder: crate::envelope::EnvelopeEncoder::new(compression, compression_policy),
            trailers,
            finalizer,
            pending_final: None,
            pending_payload: None,
            done: false,
        }
    }

    /// Flush whatever's accumulated in `buf` as a data frame.
    #[inline]
    fn flush_buf(&mut self) -> Frame<Bytes> {
        Frame::data(self.buf.split().freeze())
    }
}

impl Stream for BatchingEnvelopeStream {
    type Item = Result<Frame<Bytes>, Infallible>;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut TaskContext<'_>) -> Poll<Option<Self::Item>> {
        if self.done {
            return Poll::Ready(None);
        }

        // Staged large payload from a prior poll — its envelope header was
        // already flushed, so this must precede everything else (including
        // a staged finalizer).
        if let Some(payload) = self.pending_payload.take() {
            return Poll::Ready(Some(Ok(Frame::data(payload))));
        }

        // Staged finalizer from a prior poll (buf was non-empty at stream end).
        if let Some(frame) = self.pending_final.take() {
            self.done = true;
            return Poll::Ready(Some(Ok(frame)));
        }

        loop {
            match self.source.poll_next_unpin(cx) {
                Poll::Pending if self.buf.is_empty() => {
                    // Nothing buffered, nothing ready — just wait.
                    return Poll::Pending;
                }
                Poll::Pending => {
                    // Producer not ready for more *right now* — flush what
                    // we have so the client sees it without artificial delay.
                    return Poll::Ready(Some(Ok(self.flush_buf())));
                }
                Poll::Ready(None) => {
                    // Source exhausted. If buf is non-empty, flush it and
                    // stage the finalizer for next poll; otherwise emit the
                    // finalizer directly.
                    let final_frame = self.finalizer.success(&self.trailers);
                    if self.buf.is_empty() {
                        self.done = true;
                        return Poll::Ready(Some(Ok(final_frame)));
                    } else {
                        self.pending_final = Some(final_frame);
                        return Poll::Ready(Some(Ok(self.flush_buf())));
                    }
                }
                Poll::Ready(Some(Err(err))) => {
                    // Stream error — emit error finalizer. Same split-then-
                    // finalize staging as the None case.
                    tracing::debug!(
                        error = %err,
                        "streaming response: source error, emitting error trailers"
                    );
                    let final_frame = self.finalizer.error(&err, &self.trailers);
                    if self.buf.is_empty() {
                        self.done = true;
                        return Poll::Ready(Some(Ok(final_frame)));
                    } else {
                        self.pending_final = Some(final_frame);
                        return Poll::Ready(Some(Ok(self.flush_buf())));
                    }
                }
                Poll::Ready(Some(Ok(data))) => {
                    let me = &mut *self;
                    match me.encoder.encode_chained(
                        data,
                        &mut me.buf,
                        crate::envelope::MIN_CHAIN_SIZE,
                    ) {
                        Err(err) => {
                            // Envelope encoding/compression failed mid-stream.
                            // The buffer may contain prior successfully-encoded
                            // envelopes — don't drop them.
                            tracing::debug!(
                                error = %err,
                                "streaming response: envelope encoding failed"
                            );
                            let final_frame = self.finalizer.error(&err, &self.trailers);
                            if self.buf.is_empty() {
                                self.done = true;
                                return Poll::Ready(Some(Ok(final_frame)));
                            } else {
                                self.pending_final = Some(final_frame);
                                return Poll::Ready(Some(Ok(self.flush_buf())));
                            }
                        }
                        Ok(Some(payload)) => {
                            // Large payload: `buf` now ends with
                            // its 5-byte envelope header. Flush the buffer and
                            // stage the payload as the next frame, unmoved.
                            self.pending_payload = Some(payload);
                            return Poll::Ready(Some(Ok(self.flush_buf())));
                        }
                        Ok(None) => {}
                    }
                    if self.buf.len() >= STREAM_BATCH_THRESHOLD {
                        return Poll::Ready(Some(Ok(self.flush_buf())));
                    }
                    // Threshold not reached and producer still had data —
                    // loop and try to drain more.
                }
            }
        }
    }
}

/// Create a Connect-protocol envelope stream (ends with END_STREAM envelope).
fn create_envelope_stream(
    response_stream: BoxStream<Result<Bytes, ConnectError>>,
    trailers: http::HeaderMap,
    compression: Option<(Arc<CompressionRegistry>, &'static str)>,
    compression_policy: CompressionPolicy,
) -> impl Stream<Item = Result<Frame<Bytes>, Infallible>> + Send {
    BatchingEnvelopeStream::new(
        response_stream,
        trailers,
        compression,
        compression_policy,
        StreamFinalizer::ConnectEndStream,
    )
}

/// Create a gRPC envelope stream that sends HTTP/2 trailers.
fn create_grpc_envelope_stream(
    response_stream: BoxStream<Result<Bytes, ConnectError>>,
    trailers: http::HeaderMap,
    compression: Option<(Arc<CompressionRegistry>, &'static str)>,
    compression_policy: CompressionPolicy,
) -> impl Stream<Item = Result<Frame<Bytes>, Infallible>> + Send {
    BatchingEnvelopeStream::new(
        response_stream,
        trailers,
        compression,
        compression_policy,
        StreamFinalizer::GrpcTrailers,
    )
}

/// Create a gRPC-Web envelope stream that encodes trailers as a body frame.
fn create_grpc_web_envelope_stream(
    response_stream: BoxStream<Result<Bytes, ConnectError>>,
    trailers: http::HeaderMap,
    compression: Option<(Arc<CompressionRegistry>, &'static str)>,
    compression_policy: CompressionPolicy,
) -> impl Stream<Item = Result<Frame<Bytes>, Infallible>> + Send {
    BatchingEnvelopeStream::new(
        response_stream,
        trailers,
        compression,
        compression_policy,
        StreamFinalizer::GrpcWebTrailers,
    )
}

/// A tower Service that handles ConnectRPC requests.
///
/// This service can be composed with other tower services or used directly
/// with frameworks like axum, tonic, or hyper.
///
/// # Example
///
/// ```rust,ignore
/// let router = Arc::new(MyGreetService).register(Router::new());
/// let service = ConnectRpcService::new(router);
/// ```
///
/// # Request Limits
///
/// By default, the service applies security limits to prevent DoS attacks:
/// - Request body: 4 MB (on-wire, before decompression)
/// - Message size: 4 MB (after decompression, applied uniformly)
/// - Element memory: 32 MiB per decode (the footprint of repeated, map,
///   string and bytes elements, which a small body can inflate — see
///   [`Limits`])
///
/// These can be configured using [`with_limits`](Self::with_limits):
///
/// ```rust,ignore
/// let service = ConnectRpcService::new(router)
///     .with_limits(Limits::default().max_message_size(8 * 1024 * 1024));
/// ```
pub struct ConnectRpcService<D = Router> {
    dispatcher: Arc<D>,
    limits: Limits,
    /// Wrapped in `Arc` so the per-request clone in `call()` is one atomic
    /// op instead of the registry's three internal Arc fields.
    compression: Arc<CompressionRegistry>,
    compression_policy: CompressionPolicy,
    deadline_policy: DeadlinePolicy,
    /// Unary interceptor chain, outermost first. The `Arc<[..]>` is one
    /// pointer to clone per request regardless of chain length.
    interceptors: Arc<[Arc<dyn Interceptor>]>,
}

// Manual Clone impl because `#[derive(Clone)]` would add a `D: Clone` bound,
// but we hold `Arc<D>` so no such bound is needed.
impl<D> Clone for ConnectRpcService<D> {
    fn clone(&self) -> Self {
        Self {
            dispatcher: Arc::clone(&self.dispatcher),
            limits: self.limits.clone(),
            compression: Arc::clone(&self.compression),
            compression_policy: self.compression_policy,
            deadline_policy: self.deadline_policy.clone(),
            interceptors: Arc::clone(&self.interceptors),
        }
    }
}

impl<D: Dispatcher> ConnectRpcService<D> {
    /// Create a new ConnectRPC service from a dispatcher.
    ///
    /// The dispatcher can be either:
    /// - a [`Router`] built via generated `FooServiceExt::register`, or
    /// - a code-generated `FooServiceServer<T>` struct for monomorphic
    ///   dispatch with no HashMap lookup or trait-object indirection.
    pub fn new(dispatcher: D) -> Self {
        Self::from_arc(Arc::new(dispatcher))
    }

    /// Create a new ConnectRPC service from an Arc'd dispatcher.
    pub fn from_arc(dispatcher: Arc<D>) -> Self {
        Self {
            dispatcher,
            limits: Limits::default(),
            compression: Arc::new(CompressionRegistry::default()),
            compression_policy: CompressionPolicy::default(),
            deadline_policy: DeadlinePolicy::new(),
            interceptors: Arc::default(),
        }
    }

    /// Configure request limits.
    ///
    /// See [`Limits`] for available options.
    #[must_use]
    pub fn with_limits(mut self, limits: Limits) -> Self {
        self.limits = limits;
        self
    }

    /// Configure the compression registry.
    ///
    /// The registry determines which compression algorithms are available
    /// for request decompression and response compression.
    #[must_use]
    pub fn with_compression(mut self, compression: CompressionRegistry) -> Self {
        self.compression = Arc::new(compression);
        self
    }

    /// Configure the compression policy.
    ///
    /// The policy controls when compression is applied (e.g., minimum message
    /// size threshold). See [`CompressionPolicy`] for details.
    #[must_use]
    pub fn with_compression_policy(mut self, policy: CompressionPolicy) -> Self {
        self.compression_policy = policy;
        self
    }

    /// Configure server-side moderation of client-asserted RPC deadlines.
    ///
    /// The default [`DeadlinePolicy::new`] is a no-op: the client's
    /// `Connect-Timeout-Ms` / `grpc-timeout` header is honored verbatim
    /// for request receipt and handler execution, but streaming response
    /// bodies are not bounded by it. Set a policy to clamp client values
    /// to an operationally sane range, supply a default when the client
    /// asserts nothing, or extend enforcement to streaming response
    /// bodies. See [`DeadlinePolicy`] for details and recommendations.
    #[must_use]
    pub fn with_deadline_policy(mut self, policy: DeadlinePolicy) -> Self {
        self.deadline_policy = policy;
        self
    }

    /// Get the current deadline policy.
    #[must_use]
    pub fn deadline_policy(&self) -> &DeadlinePolicy {
        &self.deadline_policy
    }

    /// Append a unary [`Interceptor`] to the chain.
    ///
    /// The first interceptor registered runs **outermost**: first on the
    /// way in, last on the way out (matching `connect-go`'s
    /// `WithInterceptors`). Interceptors run after envelope decoding,
    /// decompression, and header parsing, and before the handler.
    ///
    /// When no interceptors are registered the dispatch path is identical
    /// to a build without this call — there is no per-request allocation
    /// or branch beyond a single `is_empty` check.
    ///
    /// Interceptors run for unary and streaming calls alike. The unary
    /// surface is [`Interceptor::intercept_unary`]; the streaming surface
    /// (covering server-streaming, client-streaming, and bidi) is
    /// [`Interceptor::intercept_streaming`].
    ///
    /// To share one interceptor instance across multiple services, use
    /// [`with_interceptor_arc`](Self::with_interceptor_arc).
    #[must_use]
    pub fn with_interceptor(self, interceptor: impl Interceptor) -> Self {
        self.with_interceptor_arc(Arc::new(interceptor))
    }

    /// Append an already-`Arc`'d unary [`Interceptor`] to the chain.
    ///
    /// Same ordering and semantics as
    /// [`with_interceptor`](Self::with_interceptor). Use this when one
    /// interceptor instance is shared across multiple `ConnectRpcService`s
    /// — e.g. an auth interceptor whose state (a connection pool, a token
    /// cache) is process-wide and should not be duplicated per service.
    /// Most callers want [`with_interceptor`](Self::with_interceptor),
    /// which takes ownership and wraps for you.
    #[must_use]
    pub fn with_interceptor_arc(mut self, interceptor: Arc<dyn Interceptor>) -> Self {
        // The Arc<[..]> is shared across cloned service handles; rebuild
        // it on registration. Registration is a cold path.
        let mut v: Vec<Arc<dyn Interceptor>> = self.interceptors.to_vec();
        v.push(interceptor);
        self.interceptors = Arc::from(v);
        self
    }

    /// Get the current limits configuration.
    pub fn limits(&self) -> &Limits {
        &self.limits
    }

    /// Get a reference to the underlying dispatcher.
    pub fn dispatcher(&self) -> &D {
        &self.dispatcher
    }
}

/// A lightweight body for gRPC unary responses.
///
/// Yields one data frame carrying the gRPC envelope — or, for a large
/// response, just its 5-byte header followed by one data frame per payload
/// segment, each passed through by refcount — then one trailers frame (for
/// gRPC) or a final data frame (for gRPC-Web trailer encoding).
/// This avoids the overhead of `Pin<Box<dyn Stream>>` + `stream::unfold` +
/// `EnvelopeEncoder` for the common unary case.
pub struct GrpcUnaryBody {
    data: Option<Bytes>,
    /// Large message payload (post-compression, when negotiated) emitted as
    /// its own data frame after `data` (which then carries only the 5-byte
    /// envelope header), so the payload is passed through by refcount
    /// instead of copied.
    ///
    /// More than one when the encoder handed back several segments — a view
    /// re-encode captures each large borrowed field separately rather than
    /// gathering them, so they stay separate all the way to the socket.
    payload: std::collections::VecDeque<Bytes>,
    trailers: Option<GrpcUnaryTrailers>,
}

/// How trailers are delivered in a gRPC unary response.
enum GrpcUnaryTrailers {
    /// HTTP/2 trailers frame (native gRPC).
    Http2(http::HeaderMap),
    /// Body data frame with flag 0x80 (gRPC-Web).
    WebBody(Bytes),
}

impl Body for GrpcUnaryBody {
    type Data = Bytes;
    type Error = Infallible;

    fn poll_frame(
        self: Pin<&mut Self>,
        _cx: &mut TaskContext<'_>,
    ) -> Poll<Option<Result<Frame<Self::Data>, Self::Error>>> {
        let me = self.get_mut();
        if let Some(data) = me.data.take() {
            Poll::Ready(Some(Ok(Frame::data(data))))
        } else if let Some(payload) = me.payload.pop_front() {
            Poll::Ready(Some(Ok(Frame::data(payload))))
        } else if let Some(trailers) = me.trailers.take() {
            match trailers {
                GrpcUnaryTrailers::Http2(map) => Poll::Ready(Some(Ok(Frame::trailers(map)))),
                GrpcUnaryTrailers::WebBody(bytes) => Poll::Ready(Some(Ok(Frame::data(bytes)))),
            }
        } else {
            Poll::Ready(None)
        }
    }
}

/// Response body type that can be Connect unary, gRPC unary, or streaming.
#[non_exhaustive]
pub enum ConnectRpcBody {
    /// Connect protocol unary response (single `Full<Bytes>` body).
    Full(Full<Bytes>),
    /// gRPC/gRPC-Web unary response (data frame + trailers, no stream overhead).
    GrpcUnary(GrpcUnaryBody),
    /// Streaming response (server streaming, client streaming, bidi, or gRPC unary fallback).
    Streaming(StreamingResponseBody),
}

impl Body for ConnectRpcBody {
    type Data = Bytes;
    type Error = Infallible;

    fn poll_frame(
        self: Pin<&mut Self>,
        cx: &mut TaskContext<'_>,
    ) -> Poll<Option<Result<Frame<Self::Data>, Self::Error>>> {
        match self.get_mut() {
            ConnectRpcBody::Full(inner) => Pin::new(inner).poll_frame(cx),
            ConnectRpcBody::GrpcUnary(inner) => Pin::new(inner).poll_frame(cx),
            ConnectRpcBody::Streaming(inner) => Pin::new(inner).poll_frame(cx),
        }
    }
}

impl<D, B> tower::Service<Request<B>> for ConnectRpcService<D>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::error::Error + Send + Sync + 'static,
{
    type Response = Response<ConnectRpcBody>;
    type Error = Infallible;
    type Future = Pin<Box<dyn Future<Output = Result<Self::Response, Self::Error>> + Send>>;

    fn poll_ready(&mut self, _cx: &mut TaskContext<'_>) -> Poll<Result<(), Self::Error>> {
        Poll::Ready(Ok(()))
    }

    fn call(&mut self, req: Request<B>) -> Self::Future {
        let dispatcher = Arc::clone(&self.dispatcher);
        let limits = self.limits.clone();
        let compression = Arc::clone(&self.compression);
        let compression_policy = self.compression_policy;
        let deadline_policy = self.deadline_policy.clone();
        let interceptors = Arc::clone(&self.interceptors);

        // Only create and attach the tracing span when a subscriber would
        // actually observe it. For disabled-debug (the common production case),
        // `.instrument()` still wraps the future and calls span.enter()/exit()
        // on every poll — profiling showed ~0.8% CPU even with the span itself
        // disabled. Branching on enabled! avoids the wrapper entirely.
        //
        // The span must be built BEFORE the async-move captures `req`.
        let span = if tracing::enabled!(tracing::Level::DEBUG) {
            Some(tracing::debug_span!(
                "connectrpc_request",
                path = %req.uri().path(),
                method = %req.method(),
                protocol = tracing::field::Empty,
                codec = tracing::field::Empty,
            ))
        } else {
            None
        };

        let fut = async move {
            let response = match handle_request(
                dispatcher,
                req,
                limits,
                compression,
                &compression_policy,
                &deadline_policy,
                &interceptors,
            )
            .await
            {
                Ok(response) => response,
                Err(err) => error_response_either(err),
            };
            Ok(response)
        };

        match span {
            Some(span) => Box::pin(fut.instrument(span)),
            None => Box::pin(fut),
        }
    }
}

/// Handle a ConnectRPC request (unary or streaming).
#[allow(clippy::too_many_arguments)]
async fn handle_request<D, B>(
    dispatcher: Arc<D>,
    req: Request<B>,
    limits: Limits,
    compression: Arc<CompressionRegistry>,
    compression_policy: &CompressionPolicy,
    deadline_policy: &DeadlinePolicy,
    interceptors: &[Arc<dyn Interceptor>],
) -> Result<Response<ConnectRpcBody>, ConnectError>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::error::Error + Send + Sync + 'static,
{
    // Detect protocol and codec from Content-Type and record into the
    // tracing span created by ConnectRpcService::call.
    let request_protocol = Protocol::detect(req.headers());
    if let Some(ref rp) = request_protocol {
        let span = tracing::Span::current();
        span.record("protocol", tracing::field::display(rp.protocol));
        span.record("codec", tracing::field::display(rp.codec_format));
    }

    // Only GET and POST carry RPCs. Reject every other verb uniformly with
    // 405 Method Not Allowed plus an `Allow` header (connect-go parity),
    // regardless of whether a Content-Type is present. Without this, a bodyless
    // OPTIONS/HEAD request (no Content-Type, so protocol detection returns
    // None) would fall through to the unsupported-media-type path and be
    // misreported as 415. An unknown path still maps to 404.
    if req.method() != Method::GET && req.method() != Method::POST {
        return reject_unsupported_method(&*dispatcher, req, limits, deadline_policy).await;
    }

    // Connect GET requests don't have a Content-Type header, so protocol
    // detection returns None. Route GET requests directly to the unary handler
    // which handles Connect GET query parameter parsing.
    if req.method() == Method::GET {
        return handle_unary_request(
            &*dispatcher,
            req,
            limits,
            compression,
            compression_policy,
            deadline_policy,
            interceptors,
        )
        .await
        .map(|r| r.map(ConnectRpcBody::Full));
    }

    // Content type didn't resolve to a known protocol+codec. A gRPC/gRPC-Web
    // prefix with an unsupported codec (e.g. application/grpc+thrift, or
    // application/grpc+json in a proto-only build) returns a gRPC `unimplemented`
    // error so the client gets gRPC framing it can parse (the compression axis
    // returns `unimplemented` for an unsupported encoding the same way). Any
    // other unrecognized content
    // type returns HTTP 415 Unsupported Media Type with an `Accept-Post` header
    // advertising the content types this server does accept.
    if request_protocol.is_none() {
        let ct = req
            .headers()
            .get(header::CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .unwrap_or("")
            .to_owned();
        let timeout_protocol = if ct.starts_with("application/grpc-web") {
            Protocol::GrpcWeb
        } else if ct.starts_with("application/grpc") {
            Protocol::Grpc
        } else {
            Protocol::Connect
        };
        let deadline = deadline_from_headers(
            req.headers(),
            timeout_protocol,
            req.uri().path(),
            deadline_policy,
        );

        // Drain the request body to avoid broken pipe on HTTP/1.1.
        let (_parts, body) = req.into_parts();
        let _ = with_request_deadline(
            deadline,
            collect_body_limited(body, limits.max_request_body_size),
        )
        .await;

        if ct.starts_with("application/grpc-web") {
            let err = ConnectError::unimplemented("unsupported content type");
            let response = grpc_error_response(&err, Protocol::GrpcWeb, CodecFormat::Proto);
            return Ok(response.map(ConnectRpcBody::Streaming));
        } else if ct.starts_with("application/grpc") {
            let err = ConnectError::unimplemented("unsupported content type");
            let response = grpc_error_response(&err, Protocol::Grpc, CodecFormat::Proto);
            return Ok(response.map(ConnectRpcBody::Streaming));
        } else {
            // Unknown content type that doesn't match any protocol.
            // Return HTTP 415 Unsupported Media Type with no body, advertising
            // the content types we do accept via `Accept-Post` (connect-go
            // parity). The empty body means clients map the 415 status to an
            // error code (Connect: unknown) per the protocol's HTTP-status
            // mapping.
            let response = Response::builder()
                .status(StatusCode::UNSUPPORTED_MEDIA_TYPE)
                .header("accept-post", ACCEPT_POST)
                .body(Full::new(Bytes::new()))
                .unwrap();
            return Ok(response.map(ConnectRpcBody::Full));
        }
    }

    match request_protocol {
        Some(rp) if rp.is_streaming => {
            // gRPC-Web text mode (application/grpc-web-text) base64-encodes the
            // entire body. We detect it (protocol.rs) but don't decode it — reject
            // explicitly with a clear error rather than failing with garbage-envelope
            // noise. Text mode is primarily for legacy browsers without binary
            // body support.
            if rp.is_text_mode {
                let err = ConnectError::unimplemented(
                    "gRPC-Web text mode (application/grpc-web-text) is not supported",
                );
                // Drain the body to preserve HTTP/1.1 keep-alive for the error response.
                let deadline = deadline_from_headers(
                    req.headers(),
                    rp.protocol,
                    req.uri().path(),
                    deadline_policy,
                );
                let (_parts, body) = req.into_parts();
                let _ = with_request_deadline(
                    deadline,
                    collect_body_limited(body, limits.max_request_body_size),
                )
                .await;
                let response = grpc_error_response(&err, Protocol::GrpcWeb, rp.codec_format);
                return Ok(response.map(ConnectRpcBody::Streaming));
            }

            // If so, take the fast path that avoids stream wrapping overhead.
            if matches!(rp.protocol, Protocol::Grpc | Protocol::GrpcWeb) {
                let path = req.uri().path();
                let path = path.strip_prefix('/').unwrap_or(path);
                if let Some(desc) = dispatcher.lookup(path)
                    && desc.kind == MethodKind::Unary
                {
                    let path = path.to_owned();
                    let response = handle_grpc_unary_request(
                        &*dispatcher,
                        &path,
                        desc.spec,
                        req,
                        rp.protocol,
                        rp.codec_format,
                        limits,
                        compression,
                        compression_policy,
                        deadline_policy,
                        interceptors,
                    )
                    .await;
                    return Ok(response.map(ConnectRpcBody::GrpcUnary));
                }
            }

            // Streaming request (Connect streaming, gRPC, or gRPC-Web)
            let response = handle_streaming_request(
                &*dispatcher,
                req,
                rp.protocol,
                rp.codec_format,
                limits,
                compression,
                compression_policy,
                deadline_policy,
                interceptors,
            )
            .await;
            Ok(response.map(ConnectRpcBody::Streaming))
        }
        Some(_) | None => {
            // Unary request (Connect unary) or unknown content type (for error reporting)
            handle_unary_request(
                &*dispatcher,
                req,
                limits,
                compression,
                compression_policy,
                deadline_policy,
                interceptors,
            )
            .await
            .map(|r| r.map(ConnectRpcBody::Full))
        }
    }
}

/// `Accept-Post` advertised on a 415 response: the content types this server
/// accepts. JSON media types appear only when the `json` feature is enabled — a
/// proto-only build advertises proto-only. gRPC-Web text mode is intentionally
/// omitted: the server detects but rejects it (`Unimplemented`), so it must not
/// be advertised as accepted.
#[cfg(feature = "json")]
const ACCEPT_POST: &str = "application/connect+json, application/connect+proto, \
application/grpc, application/grpc+json, application/grpc+proto, \
application/grpc-web, application/grpc-web+json, application/grpc-web+proto, \
application/json, application/proto";

/// See the `json`-enabled variant; a proto-only build drops every JSON media
/// type so it never advertises a codec it cannot serve.
#[cfg(not(feature = "json"))]
const ACCEPT_POST: &str = "application/connect+proto, application/grpc, \
application/grpc+proto, application/grpc-web, application/grpc-web+proto, \
application/proto";

/// Reject an HTTP method other than GET or POST.
///
/// Mirrors connect-go: a known procedure path returns 405 Method Not Allowed
/// with an `Allow` header listing the methods it accepts (always `POST`; plus
/// `GET` for idempotent unary methods). An unknown path returns the same
/// `unimplemented` (HTTP 404) as any other route miss. The request body is
/// drained first so HTTP/1.1 connections stay reusable.
async fn reject_unsupported_method<D, B>(
    dispatcher: &D,
    req: Request<B>,
    limits: Limits,
    deadline_policy: &DeadlinePolicy,
) -> Result<Response<ConnectRpcBody>, ConnectError>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::error::Error + Send + Sync + 'static,
{
    let raw_path = req.uri().path();
    let path = raw_path.strip_prefix('/').unwrap_or(raw_path).to_owned();
    let allow = dispatcher.lookup(&path).map(|desc| {
        if desc.kind == MethodKind::Unary && desc.idempotent {
            "GET, POST"
        } else {
            "POST"
        }
    });

    // Drain the request body so an early response doesn't break HTTP/1.1
    // keep-alive (see the streaming body-drop race notes).
    let deadline = deadline_from_headers(
        req.headers(),
        Protocol::Connect,
        req.uri().path(),
        deadline_policy,
    );
    let (_parts, body) = req.into_parts();
    let _ = with_request_deadline(
        deadline,
        collect_body_limited(body, limits.max_request_body_size),
    )
    .await;

    match allow {
        // Bare 405 with `Allow`: the empty body makes the client map the 405
        // status to an error code (Connect: unknown) per the HTTP-status table.
        Some(allow) => {
            let response = Response::builder()
                .status(StatusCode::METHOD_NOT_ALLOWED)
                .header(header::ALLOW, allow)
                .body(Full::new(Bytes::new()))
                .unwrap();
            Ok(response.map(ConnectRpcBody::Full))
        }
        None => Err(
            ConnectError::unimplemented(format!("method not found: {path}"))
                .with_http_status(StatusCode::NOT_FOUND),
        ),
    }
}

/// Handle a unary ConnectRPC request.
#[allow(clippy::too_many_arguments)]
async fn handle_unary_request<D, B>(
    dispatcher: &D,
    req: Request<B>,
    limits: Limits,
    compression: Arc<CompressionRegistry>,
    compression_policy: &CompressionPolicy,
    deadline_policy: &DeadlinePolicy,
    interceptors: &[Arc<dyn Interceptor>],
) -> Result<Response<Full<Bytes>>, ConnectError>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::error::Error + Send + Sync + 'static,
{
    // Parse the path to extract service/method (owned to avoid borrowing req)
    let path = req.uri().path();
    let path = path.strip_prefix('/').unwrap_or(path).to_owned();
    let query_string = req.uri().query().map(|s| s.to_owned());
    let method = req.method().clone();

    // Extract metadata from headers using the Connect protocol (unary is always Connect)
    let mut metadata = RequestMetadata::from_headers(req.headers(), Protocol::Connect);
    metadata.timeout = deadline_policy.moderate(metadata.timeout, &path);
    let deadline = absolute_deadline(metadata.timeout);

    // Split request to consume the body
    let (parts, body) = req.into_parts();
    let extensions = parts.extensions;

    // IMPORTANT: Read the full request body BEFORE returning any errors.
    // For HTTP/1.1, returning an error without reading the body causes
    // "broken pipe" errors because the client is still sending data.
    // collect_body_limited bounds allocation *during* the read, so an
    // oversized body is rejected before it is fully buffered.
    let post_body = with_request_deadline(
        deadline,
        collect_body_limited(body, limits.max_request_body_size),
    )
    .await?;

    // Look up the method descriptor to check idempotency.
    // (Non-unary kinds are allowed through — they'll error at the dispatch call.)
    let desc = dispatcher.lookup(&path).ok_or_else(|| {
        ConnectError::unimplemented(format!("method not found: {path}"))
            .with_http_status(StatusCode::NOT_FOUND)
    })?;
    let is_idempotent = desc.idempotent;

    // Handle GET vs POST requests
    let (body, codec_format) = if method == Method::GET {
        // GET requests are only allowed for idempotent methods
        if !is_idempotent {
            return Err(ConnectError::method_not_allowed(
                "GET requests are only supported for idempotent methods",
            ));
        }

        // Parse query parameters for GET request
        let params = parse_get_query_params(query_string.as_deref())?;

        // Validate connect version from query param
        if let Some(ref version) = params.connect_version
            && version != "v1"
        {
            return Err(ConnectError::invalid_argument(
                "unsupported protocol version",
            ));
        }

        // Decode message from query parameter
        let message = decode_get_message(&params, &compression, limits.max_message_size)?;

        // Get codec format from encoding query param
        let encoding = params.encoding.as_deref().unwrap_or("proto");
        let codec_format = CodecFormat::from_codec(encoding).ok_or_else(|| {
            ConnectError::unsupported_media_type(format!("unsupported encoding: {encoding}"))
        })?;

        (message, codec_format)
    } else if method == Method::POST {
        // Validate Connect-Protocol-Version header for POST
        if let Some(ref version) = metadata.protocol_version
            && version != "1"
        {
            return Err(ConnectError::invalid_argument(
                "unsupported protocol version",
            ));
        }

        // Check content type and determine codec format
        let content_type_str = metadata
            .content_type
            .as_deref()
            .unwrap_or(content_type::PROTO);

        let codec_format = CodecFormat::from_content_type(content_type_str).ok_or_else(|| {
            ConnectError::unsupported_media_type(format!(
                "unsupported content type: {content_type_str}"
            ))
        })?;

        // Body size was already enforced by collect_body_limited above.

        // Decompress if needed
        let body = if let Some(ref encoding) = metadata.unary_encoding {
            compression.decompress_with_limit(encoding, post_body, limits.max_message_size)?
        } else {
            post_body
        };

        // Check message size limit (for uncompressed messages; compressed ones
        // are already bounded by decompress_with_limit)
        if body.len() > limits.max_message_size {
            return Err(ConnectError::resource_exhausted(format!(
                "message size {} exceeds limit {}",
                body.len(),
                limits.max_message_size
            )));
        }

        (body, codec_format)
    } else {
        // Backstop: `handle_request` rejects every non-GET/POST verb upstream
        // (with 405 + `Allow`), so this arm is unreachable in normal dispatch.
        return Err(ConnectError::method_not_allowed(
            "only GET and POST methods are supported",
        ));
    };

    // Create handler context with the request headers from metadata.
    let ctx = RequestContext::new(metadata.headers)
        .with_deadline(deadline)
        .with_extensions(extensions)
        .with_spec(desc.spec)
        .with_protocol(Some(Protocol::Connect))
        // The leading slash was stripped for the Dispatcher::lookup key;
        // restore it so RequestContext::path() matches http::Uri::path()
        // and Spec::procedure.
        .with_path(format!("/{path}"))
        .with_decode_options(limits.decode_options());

    // Call the handler with the appropriate codec format.
    let resp: EncodedResponse = with_request_deadline(
        deadline,
        call_unary_intercepted(dispatcher, interceptors, &path, ctx, body, codec_format),
    )
    .await?;

    // Negotiate response compression
    let response_encoding = compression.negotiate_encoding(
        metadata.unary_accept_encoding.as_deref(),
        metadata.unary_encoding.as_deref(),
    );

    // Compress response body if negotiated, respecting the compression policy
    let effective_policy = compression_policy.with_override(resp.compress);
    // Connect unary flattens. Compression needs one contiguous input, and the
    // uncompressed case would need `Full<Bytes>` replaced with a multi-frame
    // body to carry segments — Connect puts the message straight in the HTTP
    // body, so nothing here splits it for us the way an envelope does. The
    // segmented encode therefore reaches only gRPC and gRPC-Web unary.
    // Flattening is a no-op unless the encoder segmented.
    let body_len = resp.body.len();
    let resp_body = resp.body.into_contiguous();
    let (final_body, content_encoding) = if let Some(encoding) = response_encoding {
        if effective_policy.should_compress(body_len) {
            match compression.compress(encoding, &resp_body) {
                Ok(compressed) => (compressed, Some(encoding)),
                Err(_) => (resp_body, None), // Fall back to uncompressed
            }
        } else {
            (resp_body, None)
        }
    } else {
        (resp_body, None)
    };

    // Build response with the same content type as the request
    let mut response = Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, codec_format.content_type());

    if let Some(encoding) = content_encoding {
        response = response.header(header::CONTENT_ENCODING, encoding);
    }

    // Advertise what encodings we accept (optional per spec, informational)
    let accept = compression.accept_encoding_header();
    if !accept.is_empty() {
        response = response.header(header::ACCEPT_ENCODING, accept);
    }

    // Add response headers set by the handler
    for (key, value) in resp.headers.iter() {
        response = response.header(key, value);
    }

    // Add trailers as trailer- prefixed headers
    let response = add_trailers(response, &resp.trailers);

    response
        .body(Full::new(final_body))
        .map_err(|e| ConnectError::internal(format!("failed to build response: {e}")))
}

/// Handle a gRPC/gRPC-Web unary request via the fast path.
///
/// This avoids the overhead of `handle_streaming_request` for unary RPCs:
/// no `BoxStream`, no `stream::unfold`, no `EnvelopeEncoder` — just inline
/// envelope decoding/encoding and a lightweight two-frame body.
#[allow(clippy::too_many_arguments)]
async fn handle_grpc_unary_request<D, B>(
    dispatcher: &D,
    path: &str,
    spec: Option<crate::spec::Spec>,
    req: Request<B>,
    protocol: Protocol,
    codec_format: CodecFormat,
    limits: Limits,
    compression: Arc<CompressionRegistry>,
    compression_policy: &CompressionPolicy,
    deadline_policy: &DeadlinePolicy,
    interceptors: &[Arc<dyn Interceptor>],
) -> Response<GrpcUnaryBody>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::error::Error + Send + Sync + 'static,
{
    // Extract metadata before any body reads, including error-path drains.
    let mut metadata = RequestMetadata::from_headers(req.headers(), protocol);
    metadata.timeout = deadline_policy.moderate(metadata.timeout, path);
    let deadline = absolute_deadline(metadata.timeout);

    // Helper to build a gRPC trailers-only error response using GrpcUnaryBody.
    let grpc_unary_error = |err: &ConnectError| -> Response<GrpcUnaryBody> {
        let grpc_trailers = build_grpc_trailers(Some(err), err.trailers());
        let trailers = match protocol {
            Protocol::Grpc => GrpcUnaryTrailers::Http2(grpc_trailers),
            Protocol::GrpcWeb => {
                GrpcUnaryTrailers::WebBody(encode_grpc_web_trailers(&grpc_trailers))
            }
            Protocol::Connect => unreachable!("gRPC unary fast path is gRPC/gRPC-Web only"),
        };
        let mut response = Response::builder().status(StatusCode::OK).header(
            header::CONTENT_TYPE,
            protocol.response_content_type(codec_format, true),
        );
        // For trailers-only gRPC responses, include grpc-status in headers
        if protocol == Protocol::Grpc {
            response = response.header(&GRPC_STATUS, err.code.grpc_code());
            if let Some(val) = err
                .message
                .as_deref()
                .and_then(|m| http::HeaderValue::from_str(&grpc_percent_encode(m)).ok())
            {
                response = response.header(&GRPC_MESSAGE, val);
            }
        }
        for (key, value) in err.response_headers() {
            response = response.header(key, value);
        }
        let body = GrpcUnaryBody {
            data: None,
            payload: std::collections::VecDeque::new(),
            trailers: Some(trailers),
        };
        response.body(body).unwrap_or_else(|_| {
            Response::new(GrpcUnaryBody {
                data: None,
                payload: std::collections::VecDeque::new(),
                trailers: None,
            })
        })
    };

    // gRPC requires POST. Backstop: `handle_request` already rejects non-GET/
    // POST verbs upstream, and GET never routes here, so this is defensive.
    if req.method() != Method::POST {
        let err = ConnectError::internal(format!("invalid method for gRPC: {}", req.method()));
        // Drain the request body to avoid broken pipe on HTTP/1.1.
        let (_parts, body) = req.into_parts();
        let _ = with_request_deadline(
            deadline,
            collect_body_limited(body, limits.max_request_body_size),
        )
        .await;
        return grpc_unary_error(&err);
    }

    // Validate request compression
    if let Some(ref encoding) = metadata.streaming_encoding
        && encoding != "identity"
        && !compression.supports(encoding)
    {
        let err = ConnectError::unimplemented(format!("unsupported compression: {encoding}"));
        // Drain the request body to avoid broken pipe on HTTP/1.1.
        let (_parts, body) = req.into_parts();
        let _ = with_request_deadline(
            deadline,
            collect_body_limited(body, limits.max_request_body_size),
        )
        .await;
        return grpc_unary_error(&err);
    }

    // Read the full body. collect_body_limited bounds allocation during the
    // read, so an oversized body is rejected before it is fully buffered.
    let (parts, body) = req.into_parts();
    let extensions = parts.extensions;
    let post_body = match with_request_deadline(
        deadline,
        collect_body_limited(body, limits.max_request_body_size),
    )
    .await
    {
        Ok(bytes) => bytes,
        Err(err) => return grpc_unary_error(&err),
    };

    // Decode the gRPC envelope (5-byte header + payload)
    let request_body = if post_body.is_empty() {
        // Empty body means no envelope at all — this is an error for unary RPCs
        let err = ConnectError::unimplemented("request body is empty: expected a message");
        return grpc_unary_error(&err);
    } else {
        let mut buf = bytes::BytesMut::from(&post_body[..]);
        let envelope = match Envelope::decode_with_limit(&mut buf, limits.max_message_size) {
            Ok(Some(env)) => env,
            Ok(None) => {
                let err = ConnectError::invalid_argument("incomplete request envelope");
                return grpc_unary_error(&err);
            }
            Err(e) => return grpc_unary_error(&e),
        };

        // Reject multiple envelopes in a unary request
        if !buf.is_empty() {
            let err = ConnectError::unimplemented("unary request must have exactly one message");
            return grpc_unary_error(&err);
        }

        // Decompress if needed
        if envelope.is_compressed() {
            let encoding = match metadata.streaming_encoding.as_deref() {
                Some(enc) if enc != "identity" => enc,
                _ => {
                    let err = ConnectError::internal(format!(
                        "received compressed message without {} header",
                        protocol.content_encoding_header()
                    ));
                    return grpc_unary_error(&err);
                }
            };
            match compression.decompress_with_limit(
                encoding,
                envelope.data,
                limits.max_message_size,
            ) {
                Ok(data) => data,
                Err(e) => return grpc_unary_error(&e),
            }
        } else {
            envelope.data
        }
    };

    // Create handler context
    let ctx = RequestContext::new(metadata.headers)
        .with_deadline(deadline)
        .with_extensions(extensions)
        .with_spec(spec)
        .with_protocol(Some(protocol))
        .with_path(format!("/{path}"))
        .with_decode_options(limits.decode_options());

    // Call the handler with the same deadline used while receiving the body.
    let resp = match with_request_deadline(
        deadline,
        call_unary_intercepted(
            dispatcher,
            interceptors,
            path,
            ctx,
            request_body,
            codec_format,
        ),
    )
    .await
    {
        Ok(result) => result,
        Err(e) => return grpc_unary_error(&e),
    };

    // Negotiate response compression
    let response_encoding = compression.negotiate_encoding(
        metadata.streaming_accept_encoding.as_deref(),
        metadata.streaming_encoding.as_deref(),
    );

    // Encode response into a gRPC envelope (5-byte header + payload). Large
    // payloads are chained (header segment + payload by
    // refcount) rather than copied into a contiguous buffer.
    let effective_policy = compression_policy.with_override(resp.compress);
    let min_chain = crate::envelope::MIN_CHAIN_SIZE;
    let (encoded_data, chained_payload) = if let Some(encoding) = response_encoding
        && effective_policy.should_compress(resp.body.len())
    {
        // Compression needs one contiguous input and produces one contiguous
        // output, so any segmentation the encoder managed ends here. That is
        // the right trade: the compressor was going to read every byte anyway.
        let flat = resp.body.into_contiguous();
        match compression.compress(encoding, &flat) {
            Ok(compressed) => Envelope::encode_body_parts(
                crate::envelope::flags::COMPRESSED,
                compressed.into(),
                min_chain,
            ),
            Err(_) => {
                Envelope::encode_body_parts(crate::envelope::flags::DATA, flat.into(), min_chain)
            }
        }
    } else {
        Envelope::encode_body_parts(crate::envelope::flags::DATA, resp.body, min_chain)
    };

    // Build gRPC trailers
    let grpc_trailers = build_grpc_trailers(None, &resp.trailers);

    // Build the trailers in the appropriate format for the protocol
    let trailers = match protocol {
        Protocol::Grpc => GrpcUnaryTrailers::Http2(grpc_trailers),
        Protocol::GrpcWeb => GrpcUnaryTrailers::WebBody(encode_grpc_web_trailers(&grpc_trailers)),
        Protocol::Connect => unreachable!("Connect unary uses handle_unary_request"),
    };

    // Build response headers
    let mut response = Response::builder().status(StatusCode::OK).header(
        header::CONTENT_TYPE,
        protocol.response_content_type(codec_format, true),
    );

    if let Some(encoding) = response_encoding {
        response = response.header(protocol.content_encoding_header(), encoding);
    }

    let accept = compression.accept_encoding_header();
    if !accept.is_empty() {
        response = response.header(protocol.accept_encoding_header(), accept);
    }

    // Add response headers set by the handler
    for (key, value) in resp.headers.iter() {
        response = response.header(key, value);
    }

    let body = GrpcUnaryBody {
        data: Some(encoded_data),
        payload: chained_payload.into(),
        trailers: Some(trailers),
    };

    response.body(body).unwrap_or_else(|_| {
        let err = ConnectError::internal("failed to build response");
        grpc_unary_error(&err)
    })
}

/// For server-streaming + unary-via-gRPC-streaming, whether the method
/// is server-streaming or unary. Decides whether the single response is
/// wrapped in a one-item stream (unary) or the response stream is
/// forwarded directly (server-streaming).
#[derive(Clone, Copy, PartialEq, Eq)]
enum StreamingDispatchKind {
    ServerStreaming,
    Unary,
}

/// Handle a streaming ConnectRPC request.
///
/// For streaming RPCs, errors are returned in the EndStreamResponse envelope
/// with HTTP 200 status, not as HTTP error responses.
///
/// For gRPC, this also handles unary RPCs since all gRPC RPCs use envelope
/// framing. When a unary handler is found, the single request envelope is
/// decoded, the handler is called, and the response is envelope-framed.
#[allow(clippy::too_many_arguments)]
async fn handle_streaming_request<D, B>(
    dispatcher: &D,
    req: Request<B>,
    protocol: Protocol,
    codec_format: CodecFormat,
    limits: Limits,
    compression: Arc<CompressionRegistry>,
    compression_policy: &CompressionPolicy,
    deadline_policy: &DeadlinePolicy,
    interceptors: &[Arc<dyn Interceptor>],
) -> Response<StreamingResponseBody>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::error::Error + Send + Sync + 'static,
{
    // Parse the path to extract service/method
    let path = req.uri().path();
    let path = path.strip_prefix('/').unwrap_or(path).to_owned();

    // Extract metadata before any body reads, including error-path drains.
    let mut metadata = RequestMetadata::from_headers(req.headers(), protocol);
    metadata.timeout = deadline_policy.moderate(metadata.timeout, &path);

    // gRPC and gRPC-Web require POST method. Backstop: non-GET/POST verbs are
    // already rejected upstream in `handle_request`, and GET never routes here.
    if matches!(protocol, Protocol::Grpc | Protocol::GrpcWeb) && req.method() != Method::POST {
        let err = ConnectError::internal(format!("invalid method for gRPC: {}", req.method()));
        // Drain the request body to avoid broken pipe on HTTP/1.1.
        let (_parts, body) = req.into_parts();
        let deadline = absolute_deadline(metadata.timeout);
        let _ = with_request_deadline(
            deadline,
            collect_body_limited(body, limits.max_request_body_size),
        )
        .await;
        return streaming_error_response(&err, protocol, codec_format);
    }

    // Validate request compression is supported (if specified)
    if let Some(ref encoding) = metadata.streaming_encoding
        && encoding != "identity"
        && !compression.supports(encoding)
    {
        let err = ConnectError::unimplemented(format!("unsupported compression: {encoding}"));
        // Drain the request body to avoid broken pipe on HTTP/1.1.
        let (_parts, body) = req.into_parts();
        let deadline = absolute_deadline(metadata.timeout);
        let _ = with_request_deadline(
            deadline,
            collect_body_limited(body, limits.max_request_body_size),
        )
        .await;
        return streaming_error_response(&err, protocol, codec_format);
    }

    // Single lookup to determine method kind.
    let method_desc = dispatcher.lookup(&path);

    // Split request to consume the body
    let (parts, body) = req.into_parts();
    let extensions = parts.extensions;

    // For bidi streaming, pass the raw body stream directly (no buffering)
    if matches!(method_desc, Some(d) if d.kind == MethodKind::BidiStreaming) {
        return handle_bidi_streaming_request(
            dispatcher,
            &path,
            method_desc.and_then(|d| d.spec),
            metadata,
            body,
            extensions,
            protocol,
            codec_format,
            limits,
            compression,
            compression_policy,
            deadline_policy,
            interceptors,
        )
        .await;
    }

    // For client streaming, pass the raw body stream directly (no buffering)
    if matches!(method_desc, Some(d) if d.kind == MethodKind::ClientStreaming) {
        return handle_client_streaming_request(
            dispatcher,
            &path,
            method_desc.and_then(|d| d.spec),
            metadata,
            body,
            extensions,
            protocol,
            codec_format,
            limits,
            compression,
            compression_policy,
            interceptors,
        )
        .await;
    }

    let deadline = absolute_deadline(metadata.timeout);

    // For server streaming (or errors), read the full body (single envelope expected).
    // collect_body_limited bounds allocation during the read.
    let post_body = match with_request_deadline(
        deadline,
        collect_body_limited(body, limits.max_request_body_size),
    )
    .await
    {
        Ok(bytes) => bytes,
        Err(err) => return streaming_error_response(&err, protocol, codec_format),
    };

    // Remaining kinds: server-streaming (forward response stream) or
    // unary-through-streaming (gRPC only; wrap response in one-item stream).
    let dispatch_kind = match method_desc.map(|d| d.kind) {
        Some(MethodKind::ServerStreaming) => StreamingDispatchKind::ServerStreaming,
        Some(MethodKind::Unary) => match protocol {
            // gRPC sends unary RPCs with streaming framing, so fall through.
            Protocol::Grpc | Protocol::GrpcWeb => StreamingDispatchKind::Unary,
            Protocol::Connect => {
                let err =
                    ConnectError::invalid_argument("streaming content type used for unary method");
                return streaming_error_response(&err, protocol, codec_format);
            }
        },
        None => {
            let err = ConnectError::unimplemented(format!("method not found: {path}"));
            return streaming_error_response(&err, protocol, codec_format);
        }
        // BidiStreaming and ClientStreaming already handled above
        Some(MethodKind::BidiStreaming | MethodKind::ClientStreaming) => {
            unreachable!("bidi and client streaming handled before body buffering")
        }
    };

    // Body size was already enforced by collect_body_limited above.

    // For server streaming, the request is envelope-framed
    // Decode the envelope to get the request message
    let request_body = if post_body.is_empty() {
        // Server streaming requires exactly one request envelope
        let err = ConnectError::unimplemented("server streaming request requires a message");
        return streaming_error_response(&err, protocol, codec_format);
    } else {
        let mut buf = bytes::BytesMut::from(&post_body[..]);
        let envelope = match Envelope::decode_with_limit(&mut buf, limits.max_message_size) {
            Ok(Some(env)) => env,
            Ok(None) => {
                let err = ConnectError::invalid_argument("incomplete request envelope");
                return streaming_error_response(&err, protocol, codec_format);
            }
            Err(e) => {
                return streaming_error_response(&e, protocol, codec_format);
            }
        };

        // Check for multiple request envelopes (server streaming only allows one)
        if !buf.is_empty() {
            let err = ConnectError::unimplemented(
                "server streaming request must have exactly one message",
            );
            return streaming_error_response(&err, protocol, codec_format);
        }

        // Decompress if needed
        if envelope.is_compressed() {
            // Compressed flag requires content-encoding header
            let encoding = match metadata.streaming_encoding.as_deref() {
                Some(enc) if enc != "identity" => enc,
                _ => {
                    let err = ConnectError::internal(format!(
                        "received compressed message without {} header",
                        protocol.content_encoding_header()
                    ));
                    return streaming_error_response(&err, protocol, codec_format);
                }
            };
            match compression.decompress_with_limit(
                encoding,
                envelope.data,
                limits.max_message_size,
            ) {
                Ok(data) => data,
                Err(e) => {
                    return streaming_error_response(&e, protocol, codec_format);
                }
            }
        } else {
            envelope.data
        }
    };

    // Create handler context with the request headers from metadata
    let ctx = RequestContext::new(metadata.headers)
        .with_deadline(deadline)
        .with_extensions(extensions)
        .with_spec(method_desc.and_then(|d| d.spec))
        .with_protocol(Some(protocol))
        .with_path(format!("/{path}"))
        .with_decode_options(limits.decode_options());

    // Call the handler with the appropriate codec format.
    // For gRPC unary handlers, we wrap the single response in a one-item stream.
    let resp = match dispatch_kind {
        StreamingDispatchKind::ServerStreaming => {
            let fut = call_server_streaming_intercepted(
                dispatcher,
                interceptors,
                &path,
                ctx,
                request_body,
                codec_format,
            );
            match with_request_deadline(deadline, fut).await {
                Ok(result) => result,
                Err(e) => return streaming_error_response(&e, protocol, codec_format),
            }
        }
        StreamingDispatchKind::Unary => {
            let fut = call_unary_intercepted(
                dispatcher,
                interceptors,
                &path,
                ctx,
                request_body,
                codec_format,
            );
            match with_request_deadline(deadline, fut).await {
                // Wrap single response in a one-item stream
                // The streaming machinery carries contiguous message bytes,
                // and re-enveloping happens per item downstream, so a
                // client-streaming response flattens here.
                Ok(r) => r.map_body(|body| -> BoxStream<Result<Bytes, ConnectError>> {
                    Box::pin(futures::stream::once(
                        async move { Ok(body.into_contiguous()) },
                    ))
                }),
                Err(e) => return streaming_error_response(&e, protocol, codec_format),
            }
        }
    };

    // Negotiate response compression for streaming
    let response_encoding = compression.negotiate_encoding(
        metadata.streaming_accept_encoding.as_deref(),
        metadata.streaming_encoding.as_deref(),
    );

    // Build streaming response
    let mut response = Response::builder().status(StatusCode::OK).header(
        header::CONTENT_TYPE,
        protocol.response_content_type(codec_format, true),
    );

    if let Some(encoding) = response_encoding {
        response = response.header(protocol.content_encoding_header(), encoding);
    }

    // Advertise what encodings we accept (optional per spec, informational)
    let accept = compression.accept_encoding_header();
    if !accept.is_empty() {
        response = response.header(protocol.accept_encoding_header(), accept);
    }

    // Add response headers set by the handler
    for (key, value) in resp.headers.iter() {
        response = response.header(key, value);
    }

    let stream_compression = response_encoding.map(|encoding| (compression, encoding));
    let effective_policy = compression_policy.with_override(resp.compress);
    // Time remaining in the absolute deadline budget at the point the
    // stream starts; the wrapper arms a `tokio::time::sleep` from this so
    // the deadline does not shift relative to request arrival.
    let remaining = deadline.map(|d| d.saturating_duration_since(std::time::Instant::now()));
    let resp_body = deadline_policy.enforce_on_response_stream(resp.body, remaining);
    let body = StreamingResponseBody::new(
        resp_body,
        resp.trailers,
        protocol,
        stream_compression,
        effective_policy,
    );

    response.body(body).unwrap_or_else(|_| {
        let err = ConnectError::internal("failed to build streaming response");
        streaming_error_response(&err, protocol, codec_format)
    })
}

/// Handle a client streaming ConnectRPC request.
///
/// Client streaming RPCs receive multiple envelope-framed request messages
/// and return a single envelope-framed response with END_STREAM.
///
/// # Incremental Dispatch
///
/// The body is consumed incrementally via [`spawn_body_reader`], which runs
/// a background task that reads HTTP body frames, decodes envelopes, and
/// sends decoded payloads through an `mpsc` channel. The handler receives
/// these as a truly async stream.
///
/// # Body Draining
///
/// If the handler returns early (e.g., on error) without consuming the full
/// request stream, the reader task drains remaining body bytes (up to
/// [`MAX_DRAIN_BYTES`]) to allow HTTP/1.1 connection reuse.
#[allow(clippy::too_many_arguments)]
async fn handle_client_streaming_request<D, B>(
    dispatcher: &D,
    path: &str,
    spec: Option<crate::spec::Spec>,
    metadata: RequestMetadata,
    body: B,
    extensions: http::Extensions,
    protocol: Protocol,
    codec_format: CodecFormat,
    limits: Limits,
    compression: Arc<CompressionRegistry>,
    compression_policy: &CompressionPolicy,
    interceptors: &[Arc<dyn Interceptor>],
) -> Response<StreamingResponseBody>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::fmt::Display + Send,
{
    let (request_stream, reader_task) = spawn_body_reader(
        body,
        limits.max_message_size,
        metadata.streaming_encoding.clone(),
        Arc::clone(&compression),
    );

    let deadline = metadata
        .timeout
        .and_then(|t| std::time::Instant::now().checked_add(t));
    let ctx = RequestContext::new(metadata.headers)
        .with_deadline(deadline)
        .with_extensions(extensions)
        .with_spec(spec)
        .with_protocol(Some(protocol))
        .with_path(format!("/{path}"))
        .with_decode_options(limits.decode_options());

    // Call the handler. On error paths, the reader task is left running
    // (detached) so it can finish draining the request body — aborting it
    // early races with hyper's body-EOF detection and breaks HTTP/1.1
    // keep-alive. The task is bounded by MAX_DRAIN_BYTES.
    let handler_result = if let Some(timeout) = metadata.timeout {
        match tokio::time::timeout(
            timeout,
            call_client_streaming_intercepted(
                dispatcher,
                interceptors,
                path,
                ctx,
                request_stream,
                codec_format,
            ),
        )
        .await
        {
            Ok(result) => result,
            Err(_) => {
                drop(reader_task);
                let err = ConnectError::deadline_exceeded("request timeout");
                return streaming_error_response(&err, protocol, codec_format);
            }
        }
    } else {
        call_client_streaming_intercepted(
            dispatcher,
            interceptors,
            path,
            ctx,
            request_stream,
            codec_format,
        )
        .await
    };

    let resp = match handler_result {
        Ok(result) => result,
        Err(e) => {
            drop(reader_task);
            return streaming_error_response(&e, protocol, codec_format);
        }
    };

    // Negotiate response compression for streaming
    let response_encoding = compression.negotiate_encoding(
        metadata.streaming_accept_encoding.as_deref(),
        metadata.streaming_encoding.as_deref(),
    );

    // Build streaming response with a single data envelope + END_STREAM
    let mut response = Response::builder().status(StatusCode::OK).header(
        header::CONTENT_TYPE,
        protocol.response_content_type(codec_format, true),
    );

    if let Some(encoding) = response_encoding {
        response = response.header(protocol.content_encoding_header(), encoding);
    }

    let accept = compression.accept_encoding_header();
    if !accept.is_empty() {
        response = response.header(protocol.accept_encoding_header(), accept);
    }

    // Add response headers set by the handler
    for (key, value) in resp.headers.iter() {
        response = response.header(key, value);
    }

    let stream_compression = response_encoding.map(|encoding| (compression, encoding));
    let response_stream: BoxStream<Result<Bytes, ConnectError>> =
        Box::pin(futures::stream::once(async {
            Ok(resp.body.into_contiguous())
        }));
    let effective_policy = compression_policy.with_override(resp.compress);
    let body = StreamingResponseBody::new(
        response_stream,
        resp.trailers,
        protocol,
        stream_compression,
        effective_policy,
    )
    .with_reader_task(reader_task);

    response.body(body).unwrap_or_else(|_| {
        let err = ConnectError::internal("failed to build client streaming response");
        streaming_error_response(&err, protocol, codec_format)
    })
}

/// Maximum bytes to drain from the request body after the decoder finishes.
/// This prevents a malicious client from forcing the server to consume unbounded
/// data after a size-limit error, another decoder failure, or the END_STREAM
/// envelope (after which any further body bytes are trailing garbage).
const MAX_DRAIN_BYTES: usize = 1024 * 1024; // 1 MiB

/// Whether a [`BodyReader`] is still decoding messages or draining trailing
/// body bytes.
enum ReadMode {
    /// Decoding envelopes and forwarding messages to the handler.
    Decoding,
    /// The decoder is finished (END_STREAM, a decode error, or the handler
    /// dropped the request stream); remaining body bytes are discarded,
    /// bounded by [`MAX_DRAIN_BYTES`].
    Draining {
        /// Bytes discarded so far.
        drained: usize,
        /// Set when drain mode was entered via END_STREAM and no trailing
        /// data has been observed yet — the first trailing data logs a
        /// warning, then the flag is cleared so the warning fires at most
        /// once per request (avoiding log spam).
        pending_trailing_data_warn: bool,
    },
}

/// Decoding state for the background task spawned by [`spawn_body_reader`]:
/// turns request body frames into decoded messages on `tx`, then drains the
/// rest of the body (bounded) once the decoder is finished.
struct BodyReader {
    decoder: EnvelopeDecoder,
    buf: BytesMut,
    tx: tokio::sync::mpsc::Sender<Result<Bytes, ConnectError>>,
    mode: ReadMode,
}

impl BodyReader {
    fn new(
        max_message_size: usize,
        streaming_encoding: Option<String>,
        compression: Arc<CompressionRegistry>,
        tx: tokio::sync::mpsc::Sender<Result<Bytes, ConnectError>>,
    ) -> Self {
        Self {
            decoder: EnvelopeDecoder::new(max_message_size, streaming_encoding, compression),
            buf: BytesMut::new(),
            tx,
            mode: ReadMode::Decoding,
        }
    }

    /// Handle one data frame from the request body.
    ///
    /// Returns [`ControlFlow::Break`] when the reader should stop reading the
    /// body because the post-decoder drain limit was exceeded.
    async fn on_data(&mut self, data: Bytes) -> ControlFlow<()> {
        match &mut self.mode {
            ReadMode::Decoding => {
                self.buf.extend_from_slice(&data);
                self.decode_available().await;
                ControlFlow::Continue(())
            }
            ReadMode::Draining {
                drained,
                pending_trailing_data_warn,
            } => {
                if *pending_trailing_data_warn {
                    tracing::warn!(
                        trailing_bytes = data.len(),
                        "client sent request data after the END_STREAM envelope; discarding"
                    );
                    *pending_trailing_data_warn = false;
                }
                *drained = drained.saturating_add(data.len());
                if *drained > MAX_DRAIN_BYTES {
                    tracing::debug!(
                        drained_bytes = *drained,
                        "body drain limit reached, stopping"
                    );
                    return ControlFlow::Break(());
                }
                ControlFlow::Continue(())
            }
        }
    }

    /// Handle the end of the request body: flush any remaining complete
    /// messages out of the decoder. A client may end the body without an
    /// END_STREAM envelope — the body ending is itself the end-of-stream
    /// signal.
    async fn on_eof(&mut self) {
        if !matches!(self.mode, ReadMode::Decoding) {
            return;
        }
        loop {
            match self.decoder.decode_eof(&mut self.buf) {
                Ok(Some(data)) => {
                    // A send failure (handler dropped the stream) just ends
                    // the flush early — the caller breaks out of the read
                    // loop right after `on_eof`, so no mode change is needed.
                    if self.tx.send(Ok(data)).await.is_err() {
                        return;
                    }
                }
                Ok(None) => return,
                Err(e) => {
                    let _ = self.tx.send(Err(e)).await;
                    return;
                }
            }
        }
    }

    /// Decode and forward every complete message currently buffered,
    /// switching to drain mode if the decoder finishes.
    async fn decode_available(&mut self) {
        loop {
            match self.decoder.decode(&mut self.buf) {
                Ok(Some(data)) => {
                    if self.tx.send(Ok(data)).await.is_err() {
                        // The handler dropped the request stream; the rest of
                        // the body is drained without inspection.
                        self.enter_drain_mode(false);
                        return;
                    }
                }
                Ok(None) if self.decoder.is_done() => {
                    // The END_STREAM envelope was decoded — the stream is
                    // finished, and any further request data is a protocol
                    // violation by the client.
                    self.enter_drain_mode(true);
                    return;
                }
                Ok(None) => return, // need more data from the body
                Err(e) => {
                    let _ = self.tx.send(Err(e)).await;
                    self.enter_drain_mode(false);
                    return;
                }
            }
        }
    }

    /// Switch to bounded drain mode, releasing any bytes the decoder still
    /// holds (e.g. trailing data that arrived in the same body frame as
    /// END_STREAM, or an undecoded partial envelope after a decode error)
    /// instead of keeping them resident for the duration of the drain.
    fn enter_drain_mode(&mut self, end_stream: bool) {
        let mut pending_trailing_data_warn = end_stream;
        if pending_trailing_data_warn && !self.buf.is_empty() {
            tracing::warn!(
                trailing_bytes = self.buf.len(),
                "client sent request data after the END_STREAM envelope; discarding"
            );
            pending_trailing_data_warn = false;
        }
        self.buf = BytesMut::new();
        self.mode = ReadMode::Draining {
            drained: 0,
            pending_trailing_data_warn,
        };
    }

    /// Handle a transport-level request body error.
    ///
    /// While the reader is still decoding request messages, the failure is
    /// surfaced to the handler stream as an internal [`ConnectError`] so a
    /// truncated or failed body is not mistaken for a complete client stream.
    /// Once the reader is only draining trailing bytes (after END_STREAM, a
    /// decode error, or the handler dropping the request stream), the error is
    /// diagnostic-only — the handler has already seen the terminal outcome.
    ///
    /// The code is `internal` deliberately, for parity with the unary
    /// body-read path (`collect_body_limited`): the same transport failure
    /// reports the same code regardless of RPC shape. connect-go reports
    /// `unknown` here; if the attribution is ever revisited (a broken
    /// inbound transport is arguably `unavailable`), change both paths
    /// together.
    async fn on_body_error(&mut self, err: impl std::fmt::Display + Send) {
        tracing::debug!(error = %err, "request body error, stopping reader");

        // Only the decoding path allocates the message; the drain path logs
        // via `Display` above and returns without touching the handler.
        if matches!(self.mode, ReadMode::Decoding) {
            let _ = self
                .tx
                .send(Err(ConnectError::internal(format!(
                    "failed to read request body: {err}"
                ))))
                .await;
        }
    }
}

/// Spawn a background task that reads envelope-framed messages from an HTTP
/// body and forwards them to a channel.
///
/// Returns a `(request_stream, reader_task)` pair. The `request_stream` yields
/// decoded message payloads. The `reader_task` should be attached to the
/// response via [`StreamingResponseBody::with_reader_task`]. The handle is
/// held for lifetime association but is NOT aborted when the response drops —
/// the task must be allowed to finish draining or hyper's dispatcher will see
/// the body dropped before EOF and close the connection.
///
/// When the channel receiver is dropped (e.g., the handler finishes or
/// encounters an error), the reader task continues consuming remaining body
/// bytes (up to [`MAX_DRAIN_BYTES`]) before completing. This is critical for
/// HTTP/1.1 where the server must read the entire request body before it can
/// send the response.
fn spawn_body_reader<B>(
    body: B,
    max_message_size: usize,
    streaming_encoding: Option<String>,
    compression: Arc<CompressionRegistry>,
) -> (
    BoxStream<Result<Bytes, ConnectError>>,
    Option<tokio::task::JoinHandle<()>>,
)
where
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::fmt::Display + Send,
{
    let (tx, rx) = tokio::sync::mpsc::channel::<Result<Bytes, ConnectError>>(1);

    let reader_future = async move {
        let mut body = std::pin::pin!(body);
        let mut reader = BodyReader::new(max_message_size, streaming_encoding, compression, tx);

        // Read body frames until EOF, a body error, or the drain limit.
        // Continuing to read (bounded) after the decoder finishes is critical
        // for HTTP/1.1, where the server must consume the request body before
        // the response can be sent.
        loop {
            match std::future::poll_fn(|cx| body.as_mut().poll_frame(cx)).await {
                Some(Ok(frame)) => {
                    if let Ok(data) = frame.into_data()
                        && reader.on_data(data).await.is_break()
                    {
                        break;
                    }
                }
                Some(Err(e)) => {
                    reader.on_body_error(e).await;
                    break;
                }
                None => {
                    // Body EOF — flush any remaining buffered messages.
                    reader.on_eof().await;
                    break;
                }
            }
        }
    };

    // The reader runs detached — it has to outlive the response stream so it
    // can finish draining the request body.
    let reader_task = crate::spawn_detached(reader_future);

    let request_stream: BoxStream<Result<Bytes, ConnectError>> =
        Box::pin(futures::stream::unfold(rx, |mut rx| async {
            rx.recv().await.map(|item| (item, rx))
        }));

    (request_stream, reader_task)
}

/// Handle a bidi streaming ConnectRPC request.
///
/// Bidi streaming RPCs receive multiple envelope-framed request messages
/// and return multiple envelope-framed response messages with END_STREAM.
///
/// The reader task is attached to the response body via
/// [`StreamingResponseBody::with_reader_task`]. When the response body drops,
/// the task is **detached** (not aborted) — it continues draining the request
/// body until EOF or [`MAX_DRAIN_BYTES`]. Aborting early was found to race
/// with hyper's HTTP/1.1 body-EOF detection (see `_reader_task` field docs).
#[allow(clippy::too_many_arguments)]
async fn handle_bidi_streaming_request<D, B>(
    dispatcher: &D,
    path: &str,
    spec: Option<crate::spec::Spec>,
    metadata: RequestMetadata,
    body: B,
    extensions: http::Extensions,
    protocol: Protocol,
    codec_format: CodecFormat,
    limits: Limits,
    compression: Arc<CompressionRegistry>,
    compression_policy: &CompressionPolicy,
    deadline_policy: &DeadlinePolicy,
    interceptors: &[Arc<dyn Interceptor>],
) -> Response<StreamingResponseBody>
where
    D: Dispatcher,
    B: Body<Data = Bytes> + Send + 'static,
    B::Error: std::fmt::Display + Send,
{
    let (request_stream, reader_task) = spawn_body_reader(
        body,
        limits.max_message_size,
        metadata.streaming_encoding.clone(),
        Arc::clone(&compression),
    );

    // Create handler context
    let deadline = metadata
        .timeout
        .and_then(|t| std::time::Instant::now().checked_add(t));
    let ctx = RequestContext::new(metadata.headers)
        .with_deadline(deadline)
        .with_extensions(extensions)
        .with_spec(spec)
        .with_protocol(Some(protocol))
        .with_path(format!("/{path}"))
        .with_decode_options(limits.decode_options());

    // Call the handler with timeout if configured
    let handler_result = if let Some(timeout) = metadata.timeout {
        match tokio::time::timeout(
            timeout,
            call_bidi_streaming_intercepted(
                dispatcher,
                interceptors,
                path,
                ctx,
                request_stream,
                codec_format,
            ),
        )
        .await
        {
            Ok(result) => result,
            Err(_) => {
                let err = ConnectError::deadline_exceeded("request timeout");
                drop(reader_task);
                return streaming_error_response(&err, protocol, codec_format);
            }
        }
    } else {
        call_bidi_streaming_intercepted(
            dispatcher,
            interceptors,
            path,
            ctx,
            request_stream,
            codec_format,
        )
        .await
    };

    let resp = match handler_result {
        Ok(result) => result,
        Err(e) => {
            drop(reader_task);
            return streaming_error_response(&e, protocol, codec_format);
        }
    };

    // Negotiate response compression for streaming
    let response_encoding = compression.negotiate_encoding(
        metadata.streaming_accept_encoding.as_deref(),
        metadata.streaming_encoding.as_deref(),
    );

    // Build streaming response
    let mut response = Response::builder().status(StatusCode::OK).header(
        header::CONTENT_TYPE,
        protocol.response_content_type(codec_format, true),
    );

    if let Some(encoding) = response_encoding {
        response = response.header(protocol.content_encoding_header(), encoding);
    }

    // Advertise what encodings we accept (optional per spec, informational)
    let accept = compression.accept_encoding_header();
    if !accept.is_empty() {
        response = response.header(protocol.accept_encoding_header(), accept);
    }

    // Add response headers set by the handler
    for (key, value) in resp.headers.iter() {
        response = response.header(key, value);
    }

    let stream_compression = response_encoding.map(|encoding| (compression, encoding));
    let effective_policy = compression_policy.with_override(resp.compress);
    // Time remaining in the absolute deadline budget at the point the
    // stream starts; the wrapper arms a `tokio::time::sleep` from this so
    // the deadline does not shift relative to request arrival.
    let remaining = deadline.map(|d| d.saturating_duration_since(std::time::Instant::now()));
    let resp_body = deadline_policy.enforce_on_response_stream(resp.body, remaining);
    let body = StreamingResponseBody::new(
        resp_body,
        resp.trailers,
        protocol,
        stream_compression,
        effective_policy,
    )
    .with_reader_task(reader_task);

    response.body(body).unwrap_or_else(|_| {
        let err = ConnectError::internal("failed to build bidi streaming response");
        streaming_error_response(&err, protocol, codec_format)
    })
}

/// Add trailers to a response builder using the Connect protocol's trailer- prefix convention.
fn add_trailers(
    mut response: http::response::Builder,
    trailers: &http::HeaderMap,
) -> http::response::Builder {
    for (key, value) in trailers.iter() {
        let trailer_key = format!("trailer-{}", key.as_str());
        response = response.header(trailer_key, value);
    }
    response
}

// ============================================================================
// gRPC Trailer Helpers
// ============================================================================

// Re-export pre-parsed gRPC header name statics from protocol::hdr so the
// response-building paths below don't re-parse the names on every request.
use crate::protocol::hdr::GRPC_MESSAGE;
use crate::protocol::hdr::GRPC_STATUS;
use crate::protocol::hdr::GRPC_STATUS_DETAILS_BIN;

/// Build an HTTP/2 trailers `HeaderMap` for a gRPC response.
///
/// For success: `grpc-status: 0`
/// For errors: `grpc-status: <code>`, `grpc-message: <percent-encoded message>`
///
/// Custom trailing metadata from the handler context is also included.
fn build_grpc_trailers(
    error: Option<&ConnectError>,
    custom_trailers: &http::HeaderMap,
) -> http::HeaderMap {
    let mut trailers = http::HeaderMap::new();

    match error {
        Some(err) => {
            trailers.insert(&GRPC_STATUS, http::HeaderValue::from(err.code.grpc_code()));
            if let Some(val) = err
                .message
                .as_deref()
                .and_then(|m| http::HeaderValue::from_str(&grpc_percent_encode(m)).ok())
            {
                trailers.insert(&GRPC_MESSAGE, val);
            }
            // Encode error details as grpc-status-details-bin (base64-encoded
            // google.rpc.Status protobuf containing the error details)
            {
                use base64::Engine;
                let status_bytes = crate::grpc_status::encode(err);
                let b64 = base64::engine::general_purpose::STANDARD_NO_PAD.encode(&status_bytes);
                if let Ok(val) = http::HeaderValue::from_str(&b64) {
                    trailers.insert(&GRPC_STATUS_DETAILS_BIN, val);
                }
            }
            // Include error-level trailers
            for (key, value) in err.trailers() {
                trailers.append(key, value.clone());
            }
        }
        None => {
            trailers.insert(&GRPC_STATUS, http::HeaderValue::from_static("0"));
        }
    }

    // Include custom trailing metadata from the handler context.
    // If the error already carries its own trailers (via .with_trailers()),
    // skip adding context trailers to avoid duplication.
    let error_has_own_trailers = error.is_some_and(|e| !e.trailers().is_empty());
    if !error_has_own_trailers {
        for (key, value) in custom_trailers.iter() {
            trailers.append(key, value.clone());
        }
    }

    trailers
}

/// Percent-encode a gRPC error message per the gRPC spec.
///
/// The gRPC spec requires that `grpc-message` values are percent-encoded,
/// specifically encoding characters outside the printable ASCII range and
/// the `%` character itself.
/// Percent-encoding set for gRPC `grpc-message` trailer values.
/// Encodes control characters (0x00-0x1F, 0x7F), `%` (0x25), and non-ASCII.
/// All other printable ASCII (0x20-0x7E except `%`) passes through.
const GRPC_MESSAGE_ENCODE_SET: &percent_encoding::AsciiSet = &percent_encoding::CONTROLS.add(b'%');

fn grpc_percent_encode(message: &str) -> String {
    percent_encoding::utf8_percent_encode(message, GRPC_MESSAGE_ENCODE_SET).to_string()
}

/// Build an error response with ConnectRpcBody body type.
fn error_response_either(err: ConnectError) -> Response<ConnectRpcBody> {
    error_response(err).map(ConnectRpcBody::Full)
}

/// Build an error response.
fn error_response(err: ConnectError) -> Response<Full<Bytes>> {
    let status = err.http_status();
    let body = err.to_json();

    let mut response = Response::builder()
        .status(status)
        .header(header::CONTENT_TYPE, content_type::JSON);

    // Add response headers from the error
    for (key, value) in err.response_headers() {
        response = response.header(key, value);
    }

    // Add trailers as trailer- prefixed headers
    let response = add_trailers(response, err.trailers());

    response.body(Full::new(body)).unwrap_or_else(|_| {
        Response::builder()
            .status(StatusCode::INTERNAL_SERVER_ERROR)
            .body(Full::new(Bytes::new()))
            .unwrap()
    })
}

impl ConnectError {
    /// Render this error as a complete HTTP response in the wire format
    /// matching the inbound request's protocol.
    ///
    /// This is the building block for `tower::Layer`s that short-circuit a
    /// request (auth, rate limiting, validation) before it reaches
    /// [`ConnectRpcService`]. A layer cannot reuse the service's internal error
    /// rendering, but still needs to produce a response that the calling
    /// client will decode as a structured error rather than a transport
    /// failure. Each protocol expects a different wire shape:
    ///
    /// - **Connect unary** (`application/proto`, `application/json`, or absent
    ///   — Connect GET requests carry no request body or `Content-Type`):
    ///   a non-200 HTTP status with a JSON error body. Connect unary error
    ///   bodies are spec-required JSON regardless of the request codec.
    /// - **Connect streaming** (`application/connect+{proto,json}`): HTTP 200
    ///   with the error in an `EndStreamResponse` envelope.
    /// - **gRPC / gRPC-Web** (`application/grpc*`): HTTP 200 with `grpc-status`
    ///   and `grpc-message` trailers (as HTTP/2 trailers for gRPC, encoded in
    ///   the body for gRPC-Web).
    ///
    /// The protocol is detected from `request_headers` via
    /// [`Protocol::detect`]. When detection fails — an unrecognized
    /// `Content-Type`, or none at all — the Connect unary JSON shape is used,
    /// which is the most universally parseable fallback.
    ///
    /// gRPC and gRPC-Web use the same framed wire shape for unary and
    /// streaming calls, so the trailers-only response is always correct
    /// regardless of the method's cardinality.
    ///
    /// # Example
    ///
    /// ```ignore
    /// use connectrpc::ConnectError;
    ///
    /// // Inside a tower::Service::call wrapping ConnectRpcService:
    /// fn call(&mut self, req: http::Request<B>) -> Self::Future {
    ///     if !self.is_authorized(&req) {
    ///         let resp = ConnectError::permission_denied("access denied")
    ///             .into_http_response(req.headers());
    ///         return Box::pin(std::future::ready(Ok(resp)));
    ///     }
    ///     // ... call inner service ...
    /// }
    /// ```
    #[must_use]
    pub fn into_http_response(self, request_headers: &http::HeaderMap) -> Response<ConnectRpcBody> {
        match Protocol::detect(request_headers) {
            Some(rp) if rp.is_streaming => {
                streaming_error_response(&self, rp.protocol, rp.codec_format)
                    .map(ConnectRpcBody::Streaming)
            }
            // Connect unary, or unknown/absent Content-Type: a non-200 HTTP
            // status with a JSON body is the only universally parseable shape.
            _ => error_response_either(self),
        }
    }
}

// ============================================================================
// Axum Integration
// ============================================================================

/// Axum router integration for ConnectRPC.
///
/// Available when the `axum` feature is enabled.
#[cfg(feature = "axum")]
#[cfg_attr(docsrs, doc(cfg(feature = "axum")))]
pub mod axum_integration {
    use super::*;
    use axum::body::Body;
    use axum::response::IntoResponse;

    impl Router {
        /// Convert this ConnectRPC router into an axum Router.
        ///
        /// The returned router handles all ConnectRPC paths registered with this router.
        /// It can be merged with other axum routes or used as a fallback.
        ///
        /// # Example
        ///
        /// ```rust,ignore
        /// use axum::{Router, routing::get};
        /// use connectrpc::Router as ConnectRouter;
        /// use std::sync::Arc;
        ///
        /// async fn health() -> &'static str {
        ///     "OK"
        /// }
        ///
        /// let connect_router =
        ///     Arc::new(MyGreetService).register(ConnectRouter::new());
        ///
        /// let app = Router::new()
        ///     .route("/health", get(health))
        ///     .fallback_service(connect_router.into_axum_service());
        /// ```
        pub fn into_axum_service(self) -> ConnectRpcService {
            ConnectRpcService::new(self)
        }

        /// Create an axum Router with the ConnectRPC handlers.
        ///
        /// This creates a catch-all route that handles all paths. Use this
        /// with `Router::merge()` or `Router::fallback()`.
        ///
        /// # Example
        ///
        /// ```rust,ignore
        /// use axum::{Router, routing::get};
        /// use connectrpc::Router as ConnectRouter;
        /// use std::sync::Arc;
        ///
        /// let connect_router =
        ///     Arc::new(MyGreetService).register(ConnectRouter::new());
        ///
        /// // Use as fallback for unmatched routes
        /// let app = Router::new()
        ///     .route("/health", get(health))
        ///     .fallback_service(connect_router.into_axum_service());
        /// ```
        pub fn into_axum_router(self) -> axum::Router {
            let service = ConnectRpcService::new(self);
            axum::Router::new().fallback_service(service)
        }
    }

    impl IntoResponse for ConnectError {
        fn into_response(self) -> axum::response::Response {
            let status = self.http_status();
            let body = self.to_json();

            let mut response = axum::response::Response::new(Body::from(body));
            *response.status_mut() = status;
            response.headers_mut().insert(
                header::CONTENT_TYPE,
                http::HeaderValue::from_static(content_type::JSON),
            );
            response
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A payload at or above `envelope::MIN_CHAIN_SIZE` must reach the body
    /// frames by refcount, not by copy: the emitted data frame references
    /// the handler's original allocation. Small envelopes (the 5-byte
    /// header) still batch into the framing buffer.
    #[tokio::test]
    async fn streaming_large_payload_is_chained_not_copied() {
        use futures::StreamExt as _;

        let payload = Bytes::from(vec![0x42u8; crate::envelope::MIN_CHAIN_SIZE]);
        let original_ptr = payload.as_ptr();
        let source = futures::stream::iter([Ok::<_, ConnectError>(payload.clone())]).boxed();
        let mut stream = std::pin::pin!(create_grpc_envelope_stream(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::disabled(),
        ));

        // Frame 1: the 5-byte envelope header (batched buffer flush).
        let head = stream.next().await.unwrap().unwrap().into_data().unwrap();
        assert_eq!(head.len(), crate::envelope::HEADER_SIZE);
        assert_eq!(head[0], crate::envelope::flags::DATA);
        assert_eq!(
            u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize,
            payload.len()
        );

        // Frame 2: the payload, by refcount — same allocation, no copy.
        let data = stream.next().await.unwrap().unwrap().into_data().unwrap();
        assert_eq!(data.len(), payload.len());
        assert!(
            std::ptr::eq(data.as_ptr(), original_ptr),
            "payload frame must reference the original allocation"
        );

        // Frame 3: gRPC trailers.
        let trailers = stream.next().await.unwrap().unwrap();
        assert!(trailers.is_trailers());
        assert!(stream.next().await.is_none());
    }

    /// Payloads below the chaining threshold are emitted as one
    /// contiguous data frame containing header + payload.
    #[tokio::test]
    async fn streaming_small_payload_stays_contiguous() {
        use futures::StreamExt as _;

        let payload = Bytes::from_static(b"small");
        let source = futures::stream::iter([Ok::<_, ConnectError>(payload.clone())]).boxed();
        let mut stream = std::pin::pin!(create_grpc_envelope_stream(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::disabled(),
        ));

        let frame = stream.next().await.unwrap().unwrap().into_data().unwrap();
        assert_eq!(frame.len(), crate::envelope::HEADER_SIZE + payload.len());
        assert_eq!(&frame[crate::envelope::HEADER_SIZE..], &payload[..]);

        let trailers = stream.next().await.unwrap().unwrap();
        assert!(trailers.is_trailers());
        assert!(stream.next().await.is_none());
    }

    /// The chained split must be invisible to an envelope decoder: bytes
    /// reassembled from the frames decode identically to the contiguous path.
    #[tokio::test]
    async fn streaming_chained_frames_reassemble_to_same_wire_bytes() {
        use futures::StreamExt as _;

        let large = Bytes::from(vec![0x5Au8; crate::envelope::MIN_CHAIN_SIZE + 7]);
        let small = Bytes::from_static(b"tail");
        let items = [
            Ok::<_, ConnectError>(small.clone()),
            Ok(large.clone()),
            Ok(small.clone()),
        ];
        let source = futures::stream::iter(items).boxed();
        let mut stream = std::pin::pin!(create_envelope_stream(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::disabled(),
        ));

        let mut wire = bytes::BytesMut::new();
        while let Some(frame) = stream.next().await {
            let frame = frame.unwrap();
            if let Ok(data) = frame.into_data() {
                wire.extend_from_slice(&data);
            }
        }

        // Decode all envelopes back out and compare to the source messages.
        let mut decoded = Vec::new();
        while let Some(env) = Envelope::decode(&mut wire).unwrap() {
            decoded.push(env);
        }
        assert_eq!(decoded.len(), 4, "3 data envelopes + 1 end-stream");
        assert_eq!(decoded[0].data, small);
        assert_eq!(decoded[1].data, large);
        assert_eq!(decoded[2].data, small);
        assert!(decoded[3].is_end_stream());
    }

    /// A source error right after a chained payload must still emit the
    /// staged payload before the error finalizer: header frame, payload
    /// frame, then trailers.
    #[tokio::test]
    async fn streaming_error_after_chained_payload_preserves_order() {
        use futures::StreamExt as _;

        let large = Bytes::from(vec![0x77u8; crate::envelope::MIN_CHAIN_SIZE]);
        let items = [
            Ok::<_, ConnectError>(large.clone()),
            Err(ConnectError::internal("boom")),
        ];
        let source = futures::stream::iter(items).boxed();
        let mut stream = std::pin::pin!(create_grpc_envelope_stream(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::disabled(),
        ));

        let head = stream.next().await.unwrap().unwrap().into_data().unwrap();
        assert_eq!(head.len(), crate::envelope::HEADER_SIZE);
        let payload = stream.next().await.unwrap().unwrap().into_data().unwrap();
        assert_eq!(payload, large);
        let trailers = stream.next().await.unwrap().unwrap();
        let map = trailers.into_trailers().unwrap();
        assert_eq!(map.get("grpc-status").unwrap(), "13", "internal = 13");
        assert!(stream.next().await.is_none());
    }

    /// GrpcUnaryBody with a chained payload yields header, payload, then
    /// trailers, in that order; the payload frame is the original
    /// allocation.
    #[tokio::test]
    async fn grpc_unary_body_chained_frame_order() {
        use http_body_util::BodyExt as _;

        let payload = Bytes::from(vec![0x33u8; crate::envelope::MIN_CHAIN_SIZE]);
        let ptr = payload.as_ptr();
        let (head, chained) = Envelope::encode_body_parts(
            crate::envelope::flags::DATA,
            payload.clone().into(),
            crate::envelope::MIN_CHAIN_SIZE,
        );
        let mut body = GrpcUnaryBody {
            data: Some(head.clone()),
            payload: chained.into(),
            trailers: Some(GrpcUnaryTrailers::Http2(http::HeaderMap::new())),
        };

        let f1 = body.frame().await.unwrap().unwrap().into_data().unwrap();
        assert_eq!(f1, head);
        assert_eq!(f1.len(), crate::envelope::HEADER_SIZE);
        let f2 = body.frame().await.unwrap().unwrap().into_data().unwrap();
        assert!(std::ptr::eq(f2.as_ptr(), ptr), "payload must not be copied");
        let f3 = body.frame().await.unwrap().unwrap();
        assert!(f3.is_trailers());
        assert!(body.frame().await.is_none());
    }

    #[test]
    fn test_service_creation() {
        let router = Router::new();
        let _service = ConnectRpcService::new(router);
    }

    #[test]
    fn test_service_clone() {
        let router = Router::new();
        let service = ConnectRpcService::new(router);
        let _cloned = service.clone();
    }

    // ========================================================================
    // collect_body_limited tests
    // ========================================================================

    #[tokio::test]
    async fn test_collect_body_limited_under_limit() {
        let body = Full::new(Bytes::from_static(b"hello"));
        let result = collect_body_limited(body, 1024).await.unwrap();
        assert_eq!(&result[..], b"hello");
    }

    #[tokio::test]
    async fn test_collect_body_limited_exact_limit() {
        // Limited uses strict > comparison — body exactly at limit succeeds.
        let body = Full::new(Bytes::from_static(b"hello"));
        let result = collect_body_limited(body, 5).await.unwrap();
        assert_eq!(&result[..], b"hello");
    }

    #[tokio::test]
    async fn test_collect_body_limited_over_limit() {
        let body = Full::new(Bytes::from_static(b"hello world"));
        let err = collect_body_limited(body, 5).await.unwrap_err();
        assert_eq!(err.code, crate::error::ErrorCode::ResourceExhausted);
        assert!(err.message.as_deref().unwrap().contains("limit 5"));
    }

    #[tokio::test(start_paused = true)]
    async fn test_unary_deadline_bounds_stalled_body_collection() {
        let router = Router::new();
        let body = http_body_util::StreamBody::new(futures::stream::pending::<
            Result<Frame<Bytes>, std::io::Error>,
        >());
        let req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .header(header::CONTENT_TYPE, "application/proto")
            .body(body)
            .unwrap();
        let deadline_policy = DeadlinePolicy::new().with_default_timeout(Duration::from_millis(1));

        let err = handle_unary_request(
            &router,
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &deadline_policy,
            &[],
        )
        .await
        .expect_err("stalled body must exceed the request deadline");
        assert_eq!(err.code, crate::error::ErrorCode::DeadlineExceeded);
    }

    #[tokio::test(start_paused = true)]
    async fn test_server_streaming_deadline_bounds_stalled_body_collection() {
        let router = Router::new();
        let body = http_body_util::StreamBody::new(futures::stream::pending::<
            Result<Frame<Bytes>, std::io::Error>,
        >());
        let req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .body(body)
            .unwrap();
        let deadline_policy = DeadlinePolicy::new().with_default_timeout(Duration::from_millis(1));

        let resp = handle_streaming_request(
            &router,
            req,
            Protocol::Grpc,
            CodecFormat::Proto,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &deadline_policy,
            &[],
        )
        .await;
        assert_eq!(
            resp.headers().get(&GRPC_STATUS).unwrap(),
            &crate::ErrorCode::DeadlineExceeded.grpc_code().to_string()
        );
    }

    #[test]
    fn test_parse_get_query_params_basic() {
        let params = parse_get_query_params(Some("message=%7B%7D&encoding=json&connect=v1"))
            .expect("should parse");
        assert_eq!(params.message, Some("%7B%7D".to_string()));
        assert_eq!(params.encoding, Some("json".to_string()));
        assert_eq!(params.connect_version, Some("v1".to_string()));
        assert!(!params.base64);
        assert!(params.compression.is_none());
    }

    #[test]
    fn test_parse_get_query_params_with_base64() {
        let params = parse_get_query_params(Some("message=e30&encoding=proto&base64=1&connect=v1"))
            .expect("should parse");
        assert_eq!(params.message, Some("e30".to_string()));
        assert_eq!(params.encoding, Some("proto".to_string()));
        assert!(params.base64);
    }

    #[test]
    fn test_parse_get_query_params_with_compression() {
        let params =
            parse_get_query_params(Some("message=abc&encoding=json&compression=gzip&base64=1"))
                .expect("should parse");
        assert_eq!(params.compression, Some("gzip".to_string()));
    }

    #[test]
    fn test_parse_get_query_params_missing_encoding() {
        let result = parse_get_query_params(Some("message=test&connect=v1"));
        assert!(result.is_err());
    }

    #[test]
    fn test_parse_get_query_params_no_query() {
        let result = parse_get_query_params(None);
        assert!(result.is_err());
    }

    #[test]
    fn test_percent_decode_basic() {
        let decoded = percent_decode("%7B%22name%22%3A%22test%22%7D").expect("should decode");
        assert_eq!(decoded, b"{\"name\":\"test\"}");
    }

    #[test]
    fn test_percent_decode_plus_as_space() {
        let decoded = percent_decode("hello+world").expect("should decode");
        assert_eq!(decoded, b"hello world");
    }

    #[test]
    fn test_percent_decode_passthrough() {
        let decoded = percent_decode("hello").expect("should decode");
        assert_eq!(decoded, b"hello");
    }

    #[test]
    fn test_decode_get_message_json() {
        let params = GetQueryParams {
            message: Some("%7B%7D".to_string()),
            encoding: Some("json".to_string()),
            base64: false,
            compression: None,
            connect_version: Some("v1".to_string()),
        };
        let compression = CompressionRegistry::default();
        let result = decode_get_message(&params, &compression, 1024 * 1024).expect("should decode");
        assert_eq!(result.as_ref(), b"{}");
    }

    #[test]
    fn test_decode_get_message_base64() {
        let params = GetQueryParams {
            message: Some("e30".to_string()), // base64 for "{}"
            encoding: Some("json".to_string()),
            base64: true,
            compression: None,
            connect_version: Some("v1".to_string()),
        };
        let compression = CompressionRegistry::default();
        let result = decode_get_message(&params, &compression, 1024 * 1024).expect("should decode");
        assert_eq!(result.as_ref(), b"{}");
    }

    #[test]
    fn test_decode_get_message_empty() {
        let params = GetQueryParams {
            message: None,
            encoding: Some("json".to_string()),
            base64: false,
            compression: None,
            connect_version: Some("v1".to_string()),
        };
        let compression = CompressionRegistry::default();
        let result = decode_get_message(&params, &compression, 1024 * 1024).expect("should decode");
        assert!(result.is_empty());
    }

    // ========================================================================
    // parse_timeout tests
    // ========================================================================

    #[test]
    fn test_parse_timeout_connect_milliseconds() {
        assert_eq!(
            parse_timeout("5000", Protocol::Connect),
            Some(Duration::from_millis(5000))
        );
    }

    #[test]
    fn test_parse_timeout_connect_zero() {
        assert_eq!(
            parse_timeout("0", Protocol::Connect),
            Some(Duration::from_millis(0))
        );
    }

    #[test]
    fn test_parse_timeout_connect_invalid() {
        assert_eq!(parse_timeout("abc", Protocol::Connect), None);
        assert_eq!(parse_timeout("", Protocol::Connect), None);
    }

    #[test]
    fn test_parse_timeout_grpc_hours() {
        assert_eq!(
            parse_timeout("1H", Protocol::Grpc),
            Some(Duration::from_secs(3600))
        );
    }

    #[test]
    fn test_parse_timeout_grpc_minutes() {
        assert_eq!(
            parse_timeout("5M", Protocol::Grpc),
            Some(Duration::from_secs(300))
        );
    }

    #[test]
    fn test_parse_timeout_grpc_seconds() {
        assert_eq!(
            parse_timeout("30S", Protocol::Grpc),
            Some(Duration::from_secs(30))
        );
    }

    #[test]
    fn test_parse_timeout_grpc_milliseconds() {
        assert_eq!(
            parse_timeout("500m", Protocol::Grpc),
            Some(Duration::from_millis(500))
        );
    }

    #[test]
    fn test_parse_timeout_grpc_microseconds() {
        assert_eq!(
            parse_timeout("100u", Protocol::Grpc),
            Some(Duration::from_micros(100))
        );
    }

    #[test]
    fn test_parse_timeout_grpc_nanoseconds() {
        assert_eq!(
            parse_timeout("999n", Protocol::Grpc),
            Some(Duration::from_nanos(999))
        );
    }

    #[test]
    fn test_parse_timeout_grpc_zero() {
        assert_eq!(
            parse_timeout("0S", Protocol::Grpc),
            Some(Duration::from_secs(0))
        );
    }

    #[test]
    fn test_parse_timeout_grpc_invalid_unit() {
        assert_eq!(parse_timeout("5X", Protocol::Grpc), None);
    }

    #[test]
    fn test_parse_timeout_grpc_no_digits() {
        assert_eq!(parse_timeout("H", Protocol::Grpc), None);
    }

    #[test]
    fn test_parse_timeout_grpc_empty() {
        assert_eq!(parse_timeout("", Protocol::Grpc), None);
    }

    #[test]
    fn test_parse_timeout_grpc_over_8_digits_rejected() {
        // gRPC spec caps at 8 digits. Before this was enforced, a header
        // like "18446744073709551615S" would parse to Duration::from_secs(u64::MAX)
        // and then panic downstream at `Instant::now() + d` (overflow).
        assert_eq!(parse_timeout("123456789S", Protocol::Grpc), None);
        let huge = format!("{}S", u64::MAX);
        assert_eq!(parse_timeout(&huge, Protocol::Grpc), None);
        // 8 digits is the boundary — this is the spec max
        assert_eq!(
            parse_timeout("99999999S", Protocol::Grpc),
            Some(Duration::from_secs(99_999_999))
        );
        // Verify the spec-max value is usable with Instant arithmetic
        let d = parse_timeout("99999999H", Protocol::Grpc).unwrap();
        assert!(std::time::Instant::now().checked_add(d).is_some());
    }

    #[test]
    fn test_parse_timeout_connect_over_10_digits_rejected() {
        // Connect spec caps at 10 digits.
        assert_eq!(parse_timeout("12345678901", Protocol::Connect), None);
        let huge = format!("{}", u64::MAX);
        assert_eq!(parse_timeout(&huge, Protocol::Connect), None);
        // 10 digits is the boundary — spec max is ≈ 115 days
        assert_eq!(
            parse_timeout("9999999999", Protocol::Connect),
            Some(Duration::from_millis(9_999_999_999))
        );
        // Verify the spec-max value is usable with Instant arithmetic
        let d = parse_timeout("9999999999", Protocol::Connect).unwrap();
        assert!(std::time::Instant::now().checked_add(d).is_some());
    }

    #[test]
    fn test_parse_timeout_grpc_non_ascii_rejected() {
        // Multi-byte trailing char would panic split_at without the is_ascii guard.
        // "5é" is 3 bytes (5 + 0xC3 0xA9), len-1 lands mid-codepoint.
        assert_eq!(parse_timeout("5é", Protocol::Grpc), None);
        // Non-ASCII in the digit portion
        assert_eq!(parse_timeout("é5m", Protocol::Grpc), None);
        // Emoji trailing
        assert_eq!(parse_timeout("5☺", Protocol::Grpc), None);
        // Connect protocol path doesn't use split_at, but verify anyway
        assert_eq!(parse_timeout("5é", Protocol::Connect), None);
    }

    #[test]
    fn test_parse_timeout_grpc_web_same_as_grpc() {
        assert_eq!(
            parse_timeout("500m", Protocol::GrpcWeb),
            Some(Duration::from_millis(500))
        );
    }

    // ========================================================================
    // gRPC helper tests
    // ========================================================================

    #[test]
    fn test_grpc_percent_encode_passthrough() {
        assert_eq!(grpc_percent_encode("hello world"), "hello world");
        assert_eq!(grpc_percent_encode("a-b_c.d"), "a-b_c.d");
    }

    #[test]
    fn test_grpc_percent_encode_percent() {
        assert_eq!(grpc_percent_encode("100%"), "100%25");
    }

    #[test]
    fn test_grpc_percent_encode_non_ascii() {
        assert_eq!(grpc_percent_encode("café"), "caf%C3%A9");
    }

    #[test]
    fn test_grpc_percent_encode_control_chars() {
        assert_eq!(grpc_percent_encode("a\nb"), "a%0Ab");
        assert_eq!(grpc_percent_encode("a\tb"), "a%09b");
    }

    #[test]
    fn test_build_grpc_trailers_success() {
        let custom = http::HeaderMap::new();
        let trailers = build_grpc_trailers(None, &custom);
        assert_eq!(trailers.get(&GRPC_STATUS).unwrap().to_str().unwrap(), "0");
        assert!(!trailers.contains_key(&GRPC_MESSAGE));
    }

    #[test]
    fn test_build_grpc_trailers_error() {
        let err = ConnectError::not_found("thing not found");
        let custom = http::HeaderMap::new();
        let trailers = build_grpc_trailers(Some(&err), &custom);
        assert_eq!(
            trailers.get(&GRPC_STATUS).unwrap().to_str().unwrap(),
            "5" // NOT_FOUND
        );
        assert_eq!(
            trailers.get(&GRPC_MESSAGE).unwrap().to_str().unwrap(),
            "thing not found"
        );
        assert!(trailers.contains_key("grpc-status-details-bin"));
    }

    #[test]
    fn test_build_grpc_trailers_custom_metadata() {
        let mut custom = http::HeaderMap::new();
        custom.insert("x-custom", http::HeaderValue::from_static("value1"));
        custom.append("x-custom", http::HeaderValue::from_static("value2"));
        let trailers = build_grpc_trailers(None, &custom);
        assert_eq!(trailers.get(&GRPC_STATUS).unwrap().to_str().unwrap(), "0");
        let values: Vec<_> = trailers
            .get_all("x-custom")
            .iter()
            .map(|v| v.to_str().unwrap())
            .collect();
        assert_eq!(values, vec!["value1", "value2"]);
    }

    #[test]
    fn test_build_grpc_trailers_dedup_error_trailers() {
        // When error has its own trailers, context trailers should be skipped
        let mut err = ConnectError::internal("error");
        err.trailers_mut()
            .insert("x-trailer", http::HeaderValue::from_static("from-error"));
        let mut custom = http::HeaderMap::new();
        custom.insert("x-trailer", http::HeaderValue::from_static("from-context"));
        let trailers = build_grpc_trailers(Some(&err), &custom);
        let values: Vec<_> = trailers
            .get_all("x-trailer")
            .iter()
            .map(|v| v.to_str().unwrap())
            .collect();
        // Should only have the error's trailer, not the context's
        assert_eq!(values, vec!["from-error"]);
    }

    #[test]
    fn test_build_grpc_trailers_no_dedup_when_error_has_no_trailers() {
        // When error has no trailers, context trailers should be included
        let err = ConnectError::internal("error");
        let mut custom = http::HeaderMap::new();
        custom.insert("x-trailer", http::HeaderValue::from_static("from-context"));
        let trailers = build_grpc_trailers(Some(&err), &custom);
        assert_eq!(
            trailers.get("x-trailer").unwrap().to_str().unwrap(),
            "from-context"
        );
    }

    #[test]
    fn test_encode_grpc_web_trailers() {
        let mut headers = http::HeaderMap::new();
        headers.insert(&GRPC_STATUS, http::HeaderValue::from_static("0"));
        let frame = encode_grpc_web_trailers(&headers);
        // Should start with 0x80 (trailer flag)
        assert_eq!(frame[0], 0x80);
        // Next 4 bytes are big-endian length
        let len = u32::from_be_bytes([frame[1], frame[2], frame[3], frame[4]]) as usize;
        assert_eq!(frame.len(), 5 + len);
        // Payload should contain the header
        let payload = std::str::from_utf8(&frame[5..]).unwrap();
        assert!(payload.contains("grpc-status: 0\r\n"));
    }

    #[test]
    fn test_encode_grpc_web_trailers_multi_header() {
        let mut headers = http::HeaderMap::new();
        headers.insert(&GRPC_STATUS, http::HeaderValue::from_static("13"));
        headers.insert(&GRPC_MESSAGE, http::HeaderValue::from_static("internal"));
        headers.insert(
            "grpc-status-details-bin",
            http::HeaderValue::from_static("abc123"),
        );
        let frame = encode_grpc_web_trailers(&headers);
        assert_eq!(frame[0], 0x80);
        let len = u32::from_be_bytes([frame[1], frame[2], frame[3], frame[4]]) as usize;
        let payload = std::str::from_utf8(&frame[5..5 + len]).unwrap();
        assert!(payload.contains("grpc-status: 13\r\n"));
        assert!(payload.contains("grpc-message: internal\r\n"));
        assert!(payload.contains("grpc-status-details-bin: abc123\r\n"));
    }

    #[test]
    fn test_encode_grpc_status_details_basic() {
        let err = ConnectError::internal("test error");
        let bytes = crate::grpc_status::encode(&err);
        // Should be valid protobuf - verify field 1 (code) is present
        // Field 1, wire type 0 (varint): tag = (1 << 3) | 0 = 8
        assert!(bytes.len() > 2);
        assert_eq!(bytes[0], 8); // tag for field 1 varint
        assert_eq!(bytes[1], 13); // INTERNAL = 13
    }

    // ========================================================================
    // BatchingEnvelopeStream tests
    // ========================================================================

    /// Drain a BatchingEnvelopeStream and count data frames vs the terminal frame.
    fn collect_frames(mut stream: BatchingEnvelopeStream) -> (Vec<Bytes>, Option<Frame<Bytes>>) {
        use futures::task::noop_waker_ref;
        let mut cx = std::task::Context::from_waker(noop_waker_ref());
        let mut data_frames = Vec::new();
        let mut terminal = None;
        loop {
            match Pin::new(&mut stream).poll_next(&mut cx) {
                Poll::Ready(Some(Ok(f))) if f.is_data() => {
                    data_frames.push(f.into_data().unwrap());
                }
                Poll::Ready(Some(Ok(f))) => {
                    terminal = Some(f);
                }
                Poll::Ready(None) => break,
                Poll::Pending => panic!("synchronous source should never be Pending"),
            }
        }
        (data_frames, terminal)
    }

    #[test]
    fn batching_sync_source_one_data_frame() {
        // 10 small synchronous items should batch into a single data frame,
        // then one trailers frame.
        let items: Vec<Result<Bytes, ConnectError>> =
            (0..10).map(|_| Ok(Bytes::from_static(b"msg"))).collect();
        let source: BoxStream<_> = Box::pin(futures::stream::iter(items));

        let stream = BatchingEnvelopeStream::new(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::default(),
            StreamFinalizer::GrpcTrailers,
        );

        let (data_frames, terminal) = collect_frames(stream);
        assert_eq!(
            data_frames.len(),
            1,
            "10 synchronous items should produce 1 batched data frame, got {}",
            data_frames.len()
        );
        // Each item is 5 (header) + 3 ("msg") = 8 bytes × 10 = 80 bytes.
        assert_eq!(data_frames[0].len(), 80);
        assert!(terminal.is_some());
        assert!(terminal.unwrap().is_trailers());
    }

    #[test]
    fn batching_threshold_splits_frames() {
        // Items large enough that the 16KB threshold forces a split.
        // 9KB items: first fills buf to 9K < 16K → loop, second fills to 18K ≥ 16K → flush.
        let big = Bytes::from(vec![b'x'; 9 * 1024]);
        let items: Vec<Result<Bytes, ConnectError>> = (0..4).map(|_| Ok(big.clone())).collect();
        let source: BoxStream<_> = Box::pin(futures::stream::iter(items));

        let stream = BatchingEnvelopeStream::new(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::default(),
            StreamFinalizer::GrpcTrailers,
        );

        let (data_frames, terminal) = collect_frames(stream);
        // 4 items of 9KB+5 each = 36,020 bytes. Threshold is 16KB.
        // After item 2: 18,010 ≥ 16K → flush frame 1.
        // After item 4: 18,010 ≥ 16K → flush frame 2.
        // Source None → buf empty → trailers directly.
        assert_eq!(data_frames.len(), 2);
        assert!(terminal.unwrap().is_trailers());
    }

    #[test]
    fn batching_empty_source_just_finalizer() {
        let source: BoxStream<_> = Box::pin(futures::stream::empty());
        let stream = BatchingEnvelopeStream::new(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::default(),
            StreamFinalizer::GrpcTrailers,
        );
        let (data_frames, terminal) = collect_frames(stream);
        assert!(data_frames.is_empty());
        assert!(terminal.unwrap().is_trailers());
    }

    #[test]
    fn batching_connect_finalizer_is_data_frame() {
        // Connect protocol finalizer is an END_STREAM envelope (data frame),
        // not an HTTP/2 trailers frame.
        let source: BoxStream<_> = Box::pin(futures::stream::once(async {
            Ok(Bytes::from_static(b"x"))
        }));
        let stream = BatchingEnvelopeStream::new(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::default(),
            StreamFinalizer::ConnectEndStream,
        );
        let (data_frames, terminal) = collect_frames(stream);
        // One data frame with the item, then the END_STREAM envelope arrives
        // as a second data frame (terminal is None because it IS a data frame).
        assert_eq!(data_frames.len(), 2);
        assert!(terminal.is_none());
        // Second frame should have the END_STREAM flag set in its envelope header.
        let end_frame = &data_frames[1];
        assert_eq!(end_frame[0], crate::envelope::flags::END_STREAM);
    }

    #[test]
    fn batching_error_after_items_stages_final() {
        // 3 items then an error: items should be flushed in one frame,
        // error trailers in the next.
        let items: Vec<Result<Bytes, ConnectError>> = vec![
            Ok(Bytes::from_static(b"a")),
            Ok(Bytes::from_static(b"b")),
            Ok(Bytes::from_static(b"c")),
            Err(ConnectError::internal("boom")),
        ];
        let source: BoxStream<_> = Box::pin(futures::stream::iter(items));
        let stream = BatchingEnvelopeStream::new(
            source,
            http::HeaderMap::new(),
            None,
            CompressionPolicy::default(),
            StreamFinalizer::GrpcTrailers,
        );
        let (data_frames, terminal) = collect_frames(stream);
        // 3 items batched into 1 data frame, then error trailers.
        assert_eq!(data_frames.len(), 1);
        assert_eq!(data_frames[0].len(), 3 * (5 + 1)); // 3× (header + 1 byte)
        let trailers = terminal.unwrap().into_trailers().unwrap();
        // Error trailers should have non-zero grpc-status.
        let status = trailers.get("grpc-status").unwrap().to_str().unwrap();
        assert_ne!(status, "0");
    }

    // ========================================================================
    // EndStreamResponse::error — trailer precedence + detail serialization
    // ========================================================================

    #[test]
    fn end_stream_error_includes_error_trailers() {
        // Error-level trailers must populate the END_STREAM metadata when
        // present, matching gRPC's build_grpc_trailers (error trailers
        // take precedence over context trailers).
        let mut err_trailers = http::HeaderMap::new();
        err_trailers.insert("x-error-info", "from-err".parse().unwrap());
        let err = ConnectError::internal("boom").with_trailers(err_trailers);

        let mut context_trailers = http::HeaderMap::new();
        context_trailers.insert("x-ctx", "from-context".parse().unwrap());

        let end = EndStreamResponse::error(&err, &context_trailers);
        let metadata = end.metadata.expect("metadata should be Some");
        assert!(
            metadata.contains_key("x-error-info"),
            "error-level trailer should be in metadata: {metadata:?}"
        );
        assert!(
            !metadata.contains_key("x-ctx"),
            "context trailer should NOT be in metadata when err has own trailers: {metadata:?}"
        );
    }

    #[test]
    fn end_stream_error_falls_back_to_context_trailers() {
        // When err has no trailers, use context trailers (pre-existing behavior).
        let err = ConnectError::internal("boom");
        let mut context_trailers = http::HeaderMap::new();
        context_trailers.insert("x-ctx", "from-context".parse().unwrap());

        let end = EndStreamResponse::error(&err, &context_trailers);
        let metadata = end.metadata.expect("metadata should be Some");
        assert!(metadata.contains_key("x-ctx"));
    }

    #[test]
    fn end_stream_error_details_include_debug_field() {
        // Details are serialized via ErrorDetail's Serialize derive so
        // all fields (including debug) appear. A hand-rolled JSON
        // construction previously dropped debug.
        let detail = crate::error::ErrorDetail {
            type_url: "test.Detail".into(),
            value: Some("YmFzZTY0".into()),
            debug: Some(serde_json::json!({"hint": "turn it off and on again"})),
        };
        let err = ConnectError::internal("boom").with_detail(detail);

        let end = EndStreamResponse::error(&err, &http::HeaderMap::new());
        let json = serde_json::to_string(&end).unwrap();

        assert!(
            json.contains("\"type\":\"test.Detail\""),
            "type missing: {json}"
        );
        assert!(
            json.contains("\"value\":\"YmFzZTY0\""),
            "value missing: {json}"
        );
        assert!(json.contains("\"debug\":"), "debug field missing: {json}");
        assert!(
            json.contains("turn it off and on again"),
            "debug content missing: {json}"
        );
    }

    // ========================================================================
    // Context.extensions passthrough
    // ========================================================================

    /// Prove that `http::Request` extensions survive the unary dispatch
    /// path and reach the handler via `Context.extensions`. A tower layer
    /// in front of `ConnectRpcService` inserts peer info this way.
    #[tokio::test]
    async fn extensions_flow_to_handler_context() {
        use std::sync::Mutex;

        #[derive(Clone, Debug, PartialEq)]
        struct PeerTag(&'static str);

        let captured = Arc::new(Mutex::new(None::<PeerTag>));
        let handler_captured = Arc::clone(&captured);
        let router = Router::new().route(
            "svc",
            "Method",
            crate::handler_fn(move |ctx: RequestContext, _req: buffa_types::Empty| {
                let cap = Arc::clone(&handler_captured);
                async move {
                    *cap.lock().unwrap() = ctx.extensions().get::<PeerTag>().cloned();
                    crate::Response::ok(buffa_types::Empty::default())
                }
            }),
        );

        let mut req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .header(header::CONTENT_TYPE, "application/proto")
            .body(Full::new(Bytes::new()))
            .unwrap();
        req.extensions_mut().insert(PeerTag("10.0.0.1:54321"));

        handle_unary_request(
            &router,
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &DeadlinePolicy::new(),
            &[],
        )
        .await
        .expect("dispatch should succeed");

        assert_eq!(
            captured.lock().unwrap().take(),
            Some(PeerTag("10.0.0.1:54321")),
            "extension inserted on the http::Request must reach Context.extensions"
        );
    }

    /// Register a `svc/Method` handler that captures
    /// `(ctx.path(), ctx.spec())`, apply `finalize` (e.g. `with_spec`),
    /// drive a request through `handle_unary_request`, and return the
    /// captured tuple.
    async fn capture_path_and_spec(
        finalize: impl FnOnce(Router) -> Router,
    ) -> (Option<String>, Option<crate::spec::Spec>) {
        use std::sync::Mutex;

        let captured = Arc::new(Mutex::new(None));
        let handler_captured = Arc::clone(&captured);
        let router = Router::new().route(
            "svc",
            "Method",
            crate::handler_fn(move |ctx: RequestContext, _req: buffa_types::Empty| {
                let cap = Arc::clone(&handler_captured);
                async move {
                    *cap.lock().unwrap() = Some((ctx.path().map(str::to_owned), ctx.spec()));
                    crate::Response::ok(buffa_types::Empty::default())
                }
            }),
        );
        let router = finalize(router);

        let req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .header(header::CONTENT_TYPE, "application/proto")
            .body(Full::new(Bytes::new()))
            .unwrap();

        handle_unary_request(
            &router,
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &DeadlinePolicy::new(),
            &[],
        )
        .await
        .expect("dispatch should succeed");

        captured.lock().unwrap().take().expect("handler ran")
    }

    /// Prove that `RequestContext::path()` carries the request URI path
    /// through the dispatch path, in the leading-slash form, *even when*
    /// `RequestContext::spec()` is `None`.
    ///
    /// A `Router` route registered without [`Router::with_spec`] supplies
    /// no [`Spec`](crate::spec::Spec) — `path()` is the only source for
    /// the procedure name in that case, and it's the one an auth
    /// interceptor or span builder must read.
    #[tokio::test]
    async fn path_flows_to_handler_context() {
        let (path, spec) = capture_path_and_spec(|r| r).await;
        assert_eq!(
            path.as_deref(),
            Some("/svc/Method"),
            "path() must carry the leading-slash request URI path"
        );
        assert!(
            spec.is_none(),
            "Router route without with_spec supplies no Spec — path() must still be populated"
        );
    }

    /// `Router::with_spec` flows through the dispatch path to
    /// `RequestContext::spec()`. A `Router` built through the generated
    /// `register()` (which chains `.with_spec(...)` after every
    /// `route_view*`) surfaces `Spec` to handlers and interceptors
    /// exactly like the monomorphic `FooServiceServer<T>` dispatcher.
    /// `path()` and `spec().procedure` must agree when both are present.
    #[tokio::test]
    async fn spec_flows_to_handler_context() {
        use crate::spec::{Spec, StreamType};
        const SPEC: Spec = Spec::server("/svc/Method", StreamType::Unary);

        let (path, spec) = capture_path_and_spec(|r| r.with_spec(SPEC)).await;
        assert_eq!(
            spec,
            Some(SPEC),
            "Router::with_spec must flow to ctx.spec()"
        );
        assert_eq!(
            path.as_deref(),
            spec.map(|s| s.procedure),
            "path() and spec().procedure must agree when both are present"
        );
    }

    /// Interceptors must run on the Connect GET path. An idempotent unary
    /// RPC accessed via HTTP GET must not bypass an authz interceptor —
    /// every dispatch shape (Connect POST, Connect GET, gRPC fast path,
    /// gRPC streaming-frame unary) routes through `call_unary_intercepted`.
    /// A regression in any one of them is silent until a client uses that
    /// shape, which for GET only happens for `idempotency_level =
    /// NO_SIDE_EFFECTS` methods.
    #[tokio::test]
    async fn interceptor_runs_on_connect_get_request() {
        use crate::interceptor::{Interceptor, Next, UnaryRequest, UnaryResponse};
        use std::sync::Mutex;
        use std::sync::atomic::{AtomicBool, Ordering};

        let intercepted = Arc::new(AtomicBool::new(false));
        let handler_ran = Arc::new(Mutex::new(false));

        let handler_ran_inner = Arc::clone(&handler_ran);
        let router = Router::new().route_idempotent(
            "svc",
            "Get",
            crate::handler_fn(move |_ctx: RequestContext, _req: buffa_types::Empty| {
                let h = Arc::clone(&handler_ran_inner);
                async move {
                    *h.lock().unwrap() = true;
                    crate::Response::ok(buffa_types::Empty::default())
                }
            }),
        );

        struct Recorder(Arc<AtomicBool>);
        #[async_trait::async_trait]
        impl Interceptor for Recorder {
            async fn intercept_unary(
                &self,
                req: UnaryRequest,
                next: Next<'_>,
            ) -> Result<UnaryResponse, ConnectError> {
                self.0.store(true, Ordering::SeqCst);
                next.run(req).await
            }
        }
        let chain: Vec<Arc<dyn Interceptor>> = vec![Arc::new(Recorder(Arc::clone(&intercepted)))];

        // A Connect GET request: empty proto message, base64-encoded
        // (empty), encoding declared. Idempotent methods opt into GET so
        // CDNs and browsers can cache them — those requests must still be
        // intercepted.
        let req = Request::builder()
            .method(Method::GET)
            .uri("/svc/Get?message=&encoding=proto&base64=1&connect=v1")
            .body(Full::new(Bytes::new()))
            .unwrap();

        handle_unary_request(
            &router,
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &DeadlinePolicy::new(),
            &chain,
        )
        .await
        .expect("dispatch should succeed");

        assert!(
            intercepted.load(Ordering::SeqCst),
            "interceptor must run on Connect GET requests"
        );
        assert!(
            *handler_ran.lock().unwrap(),
            "handler must run after the interceptor passes through"
        );
    }

    /// `with_interceptor_arc` shares one interceptor across services.
    /// `with_interceptor` would `Arc::new` a fresh allocation per call,
    /// which is correct for unique state but wasteful (and surprising)
    /// when the interceptor carries process-wide shared state — pin the
    /// distinction with a strong-count check.
    #[test]
    fn with_interceptor_arc_shares_one_instance() {
        use crate::interceptor::Interceptor;

        struct Noop;
        #[async_trait::async_trait]
        impl Interceptor for Noop {}

        let shared: Arc<dyn Interceptor> = Arc::new(Noop);
        assert_eq!(Arc::strong_count(&shared), 1);

        let svc_a = ConnectRpcService::new(Router::new()).with_interceptor_arc(Arc::clone(&shared));
        let svc_b = ConnectRpcService::new(Router::new()).with_interceptor_arc(Arc::clone(&shared));

        // The caller's handle plus one per service.
        assert_eq!(
            Arc::strong_count(&shared),
            3,
            "with_interceptor_arc must store the supplied Arc, not a fresh allocation"
        );
        // Cloning a service is one Arc<[..]> bump, not a per-interceptor bump.
        let _svc_a2 = svc_a.clone();
        assert_eq!(Arc::strong_count(&shared), 3);
        drop(svc_a);
        drop(svc_b);
        drop(_svc_a2);
        assert_eq!(Arc::strong_count(&shared), 1);
    }

    // ========================================================================
    // ConnectError::into_http_response tests
    // ========================================================================

    fn headers_with_content_type(ct: &str) -> http::HeaderMap {
        let mut headers = http::HeaderMap::new();
        headers.insert(
            header::CONTENT_TYPE,
            http::HeaderValue::from_str(ct).unwrap(),
        );
        headers
    }

    async fn body_bytes(body: ConnectRpcBody) -> Bytes {
        body.collect().await.unwrap().to_bytes()
    }

    #[tokio::test]
    async fn into_http_response_connect_unary() {
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/proto"));

        assert_eq!(resp.status(), StatusCode::FORBIDDEN);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            content_type::JSON
        );
        assert!(resp.headers().get(&GRPC_STATUS).is_none());

        let body = body_bytes(resp.into_body()).await;
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["code"], "permission_denied");
        assert_eq!(json["message"], "nope");
    }

    #[tokio::test]
    async fn into_http_response_connect_streaming() {
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/connect+proto"));

        // Connect streaming errors are HTTP 200 with an EndStreamResponse envelope.
        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            "application/connect+proto"
        );

        let body = body_bytes(resp.into_body()).await;
        // Envelope: 1 flag byte (0x02 end-stream) + 4 length bytes + JSON payload.
        assert!(body.len() > 5, "envelope must contain a payload");
        assert_eq!(body[0], 0x02, "end-stream flag bit must be set");
        let json: serde_json::Value = serde_json::from_slice(&body[5..]).unwrap();
        assert_eq!(json["error"]["code"], "permission_denied");
    }

    #[tokio::test]
    async fn into_http_response_grpc() {
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/grpc+proto"));

        // gRPC trailers-only error response: HTTP 200, grpc-status echoed in headers.
        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            "application/grpc+proto"
        );
        assert_eq!(
            resp.headers().get(&GRPC_STATUS).unwrap(),
            &crate::ErrorCode::PermissionDenied.grpc_code().to_string()
        );
    }

    #[tokio::test]
    async fn into_http_response_grpc_web() {
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/grpc-web+proto"));

        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            "application/grpc-web+proto"
        );
        // gRPC-Web encodes trailers in the body, not response headers.
        assert!(resp.headers().get(&GRPC_STATUS).is_none());

        let body = body_bytes(resp.into_body()).await;
        // Trailer frame: flag byte 0x80 + 4 length bytes + headers.
        assert!(body.len() > 5, "trailer frame must contain a payload");
        assert_eq!(body[0], 0x80, "trailer flag bit must be set");
        let trailer_text = std::str::from_utf8(&body[5..]).unwrap();
        assert!(trailer_text.contains("grpc-status: 7"), "{trailer_text:?}");
    }

    // Echoing a JSON request codec into the error response only applies when
    // the `json` feature is on; a proto-only build declines JSON content types
    // at negotiation, so these scenarios are unreachable there.
    #[cfg(feature = "json")]
    #[tokio::test]
    async fn into_http_response_connect_streaming_json_codec() {
        // The codec format from the request Content-Type must round-trip into
        // the response Content-Type, even though the EndStreamResponse payload
        // itself is always JSON.
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/connect+json"));

        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            "application/connect+json"
        );
    }

    #[cfg(feature = "json")]
    #[tokio::test]
    async fn into_http_response_grpc_json_codec() {
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/grpc+json"));

        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            "application/grpc+json"
        );
        assert_eq!(
            resp.headers().get(&GRPC_STATUS).unwrap(),
            &crate::ErrorCode::PermissionDenied.grpc_code().to_string()
        );
    }

    // The Connect protocol requires HTTP 415 Unsupported Media Type when the
    // server does not support the requested message codec. A proto-only build
    // (no `json` feature) declines every JSON content type at content
    // negotiation, before the request body is touched.
    #[cfg(not(feature = "json"))]
    #[tokio::test]
    async fn proto_only_server_rejects_json_content_types_with_415() {
        let dispatcher = Arc::new(Router::new());

        for ct in ["application/json", "application/connect+json"] {
            let req = Request::builder()
                .method(Method::POST)
                .uri("/svc/Method")
                .header(header::CONTENT_TYPE, ct)
                .body(Full::new(Bytes::new()))
                .unwrap();
            let resp = handle_request(
                Arc::clone(&dispatcher),
                req,
                Limits::default(),
                Arc::new(CompressionRegistry::new()),
                &CompressionPolicy::default(),
                &DeadlinePolicy::new(),
                &[],
            )
            .await
            .expect("415 is returned as an Ok response, not an Err");
            assert_eq!(
                resp.status(),
                StatusCode::UNSUPPORTED_MEDIA_TYPE,
                "{ct} must be rejected with HTTP 415 in a proto-only build"
            );
        }

        // A proto request passes content negotiation (it fails later as
        // route-not-found, not as a 415) — proving only JSON is declined.
        let req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .header(header::CONTENT_TYPE, "application/proto")
            .body(Full::new(Bytes::new()))
            .unwrap();
        let status = match handle_request(
            Arc::clone(&dispatcher),
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &DeadlinePolicy::new(),
            &[],
        )
        .await
        {
            Ok(resp) => resp.status(),
            Err(err) => err.http_status(),
        };
        assert_ne!(status, StatusCode::UNSUPPORTED_MEDIA_TYPE);
    }

    // A valid `application/grpc` / `application/grpc-web` prefix paired with an
    // unsupported message codec (e.g. `+thrift`) is rejected with the gRPC
    // status `unimplemented` (code 12), matching the compression axis. The
    // gRPC spec leaves this code unspecified and the conformance suite accepts
    // either `internal` or `unimplemented`; we use `unimplemented` because the
    // server genuinely does not implement the requested codec.
    #[tokio::test]
    async fn unsupported_grpc_codec_returns_unimplemented() {
        let dispatcher = Arc::new(Router::new());

        // gRPC: the trailers-only error echoes grpc-status in the response
        // headers.
        let req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .header(header::CONTENT_TYPE, "application/grpc+thrift")
            .body(Full::new(Bytes::new()))
            .unwrap();
        let resp = handle_request(
            Arc::clone(&dispatcher),
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &DeadlinePolicy::new(),
            &[],
        )
        .await
        .expect("a gRPC codec rejection is returned as an Ok response");
        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get("grpc-status").unwrap(),
            "12",
            "unsupported gRPC codec must map to unimplemented (12)"
        );

        // gRPC-Web: grpc-status is carried in the trailer frame in the body.
        let req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .header(header::CONTENT_TYPE, "application/grpc-web+thrift")
            .body(Full::new(Bytes::new()))
            .unwrap();
        let resp = handle_request(
            Arc::clone(&dispatcher),
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &DeadlinePolicy::new(),
            &[],
        )
        .await
        .expect("a gRPC-Web codec rejection is returned as an Ok response");
        assert_eq!(resp.status(), StatusCode::OK);
        let body = resp
            .into_body()
            .collect()
            .await
            .expect("collecting the gRPC-Web error body must not fail")
            .to_bytes();
        let body_text = String::from_utf8_lossy(&body);
        assert!(
            body_text.contains("grpc-status: 12\r\n"),
            "unsupported gRPC-Web codec must map to unimplemented (12); body was {body_text:?}"
        );
    }

    // Mirrors connect-go: an unsupported HTTP verb on a known procedure returns
    // 405 with an `Allow` header (POST, plus GET for idempotent unary methods);
    // an unknown path returns 404. Also covers the bug where a bodyless
    // OPTIONS/HEAD (no Content-Type) was previously misreported as 415.
    #[tokio::test]
    async fn unsupported_http_verb_returns_405_with_allow() {
        let dispatcher = Arc::new(
            Router::new()
                .route(
                    "svc",
                    "Unary",
                    crate::handler_fn(|_ctx: RequestContext, _req: buffa_types::Empty| async {
                        crate::Response::ok(buffa_types::Empty::default())
                    }),
                )
                .route_idempotent(
                    "svc",
                    "Get",
                    crate::handler_fn(|_ctx: RequestContext, _req: buffa_types::Empty| async {
                        crate::Response::ok(buffa_types::Empty::default())
                    }),
                ),
        );

        async fn call(
            dispatcher: &Arc<Router>,
            req: Request<Full<Bytes>>,
        ) -> Result<Response<ConnectRpcBody>, ConnectError> {
            handle_request(
                Arc::clone(dispatcher),
                req,
                Limits::default(),
                Arc::new(CompressionRegistry::new()),
                &CompressionPolicy::default(),
                &DeadlinePolicy::new(),
                &[],
            )
            .await
        }

        // Non-idempotent unary procedure: Allow lists POST only. Includes a
        // bodyless OPTIONS/HEAD with no Content-Type (the original 415 bug).
        for (verb, with_ct) in [
            (Method::DELETE, true),
            (Method::PUT, true),
            (Method::OPTIONS, false),
            (Method::HEAD, false),
        ] {
            let mut builder = Request::builder().method(verb.clone()).uri("/svc/Unary");
            if with_ct {
                builder = builder.header(header::CONTENT_TYPE, "application/proto");
            }
            let req = builder.body(Full::new(Bytes::new())).unwrap();
            let resp = call(&dispatcher, req)
                .await
                .expect("405 is returned as an Ok response");
            assert_eq!(resp.status(), StatusCode::METHOD_NOT_ALLOWED, "{verb}");
            assert_eq!(resp.headers().get(header::ALLOW).unwrap(), "POST", "{verb}");
        }

        // Idempotent unary procedure: Allow also lists GET.
        let req = Request::builder()
            .method(Method::DELETE)
            .uri("/svc/Get")
            .body(Full::new(Bytes::new()))
            .unwrap();
        let resp = call(&dispatcher, req).await.expect("405");
        assert_eq!(resp.status(), StatusCode::METHOD_NOT_ALLOWED);
        assert_eq!(resp.headers().get(header::ALLOW).unwrap(), "GET, POST");

        // Unknown path with a bad verb maps to 404 route-not-found.
        let req = Request::builder()
            .method(Method::DELETE)
            .uri("/svc/Missing")
            .body(Full::new(Bytes::new()))
            .unwrap();
        let status = match call(&dispatcher, req).await {
            Ok(resp) => resp.status(),
            Err(err) => err.http_status(),
        };
        assert_eq!(status, StatusCode::NOT_FOUND);
    }

    // A 415 advertises the content types the server accepts via `Accept-Post`
    // (connect-go parity); a proto-only build never lists a JSON media type.
    #[tokio::test]
    async fn unknown_content_type_returns_415_with_accept_post() {
        let dispatcher = Arc::new(Router::new());
        let req = Request::builder()
            .method(Method::POST)
            .uri("/svc/Method")
            .header(header::CONTENT_TYPE, "application/foo")
            .body(Full::new(Bytes::new()))
            .unwrap();
        let resp = handle_request(
            Arc::clone(&dispatcher),
            req,
            Limits::default(),
            Arc::new(CompressionRegistry::new()),
            &CompressionPolicy::default(),
            &DeadlinePolicy::new(),
            &[],
        )
        .await
        .expect("415 is returned as an Ok response");
        assert_eq!(resp.status(), StatusCode::UNSUPPORTED_MEDIA_TYPE);

        let accept_post = resp
            .headers()
            .get("accept-post")
            .expect("415 advertises Accept-Post")
            .to_str()
            .unwrap();
        assert!(accept_post.contains("application/proto"), "{accept_post}");
        #[cfg(feature = "json")]
        assert!(accept_post.contains("application/json"), "{accept_post}");
        #[cfg(not(feature = "json"))]
        assert!(
            !accept_post.contains("json"),
            "proto-only must not advertise json: {accept_post}"
        );
    }

    #[tokio::test]
    async fn into_http_response_grpc_web_text_mode() {
        // gRPC-Web text mode (`application/grpc-web-text`) is detected as
        // gRPC-Web; the trailers-only error body has the same wire shape as
        // binary mode (the service rejects text-mode requests, but a layer
        // running before dispatch must still produce *something* parseable).
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/grpc-web-text"));

        assert_eq!(resp.status(), StatusCode::OK);
        assert!(resp.headers().get(&GRPC_STATUS).is_none());

        let body = body_bytes(resp.into_body()).await;
        assert_eq!(body[0], 0x80, "trailer flag bit must be set");
    }

    #[tokio::test]
    async fn into_http_response_content_type_with_parameters() {
        // Parameters after `;` must not defeat protocol detection.
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type(
            "application/grpc+proto; foo=bar",
        ));

        assert_eq!(resp.status(), StatusCode::OK);
        assert_eq!(
            resp.headers().get(&GRPC_STATUS).unwrap(),
            &crate::ErrorCode::PermissionDenied.grpc_code().to_string()
        );
    }

    #[tokio::test]
    async fn into_http_response_connect_unary_proto_request_returns_json_error() {
        // Connect unary errors are spec-required to be JSON regardless of the
        // request codec. A proto request must not get a proto-encoded error.
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&headers_with_content_type("application/proto"));

        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            content_type::JSON,
            "Connect unary error body must be JSON regardless of request codec"
        );
    }

    #[tokio::test]
    async fn into_http_response_no_content_type_falls_back_to_unary() {
        // Connect GET requests have no request Content-Type; they expect the
        // Connect unary JSON error shape.
        let err = ConnectError::permission_denied("nope");
        let resp = err.into_http_response(&http::HeaderMap::new());

        assert_eq!(resp.status(), StatusCode::FORBIDDEN);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            content_type::JSON
        );
    }

    #[tokio::test]
    async fn into_http_response_unknown_content_type_falls_back_to_unary() {
        let err = ConnectError::unauthenticated("who?");
        let resp = err.into_http_response(&headers_with_content_type("text/plain"));

        assert_eq!(resp.status(), StatusCode::UNAUTHORIZED);
        assert_eq!(
            resp.headers().get(header::CONTENT_TYPE).unwrap(),
            content_type::JSON
        );

        let body = body_bytes(resp.into_body()).await;
        let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["code"], "unauthenticated");
    }

    // ========================================================================
    // spawn_body_reader tests
    // ========================================================================

    /// Test body that yields a fixed sequence of data frames and records how
    /// many bytes the reader actually pulls from it.
    struct CountingBody {
        frames: std::collections::VecDeque<Bytes>,
        pulled: Arc<std::sync::atomic::AtomicUsize>,
    }

    impl Body for CountingBody {
        type Data = Bytes;
        type Error = Infallible;

        fn poll_frame(
            self: Pin<&mut Self>,
            _cx: &mut TaskContext<'_>,
        ) -> Poll<Option<Result<Frame<Self::Data>, Self::Error>>> {
            let this = self.get_mut();
            match this.frames.pop_front() {
                Some(data) => {
                    this.pulled
                        .fetch_add(data.len(), std::sync::atomic::Ordering::Relaxed);
                    Poll::Ready(Some(Ok(Frame::data(data))))
                }
                None => Poll::Ready(None),
            }
        }
    }

    /// Regression test: a client that sends a valid END_STREAM envelope and
    /// then keeps sending request body data must not cause unbounded
    /// buffering. The reader must treat END_STREAM as terminal and switch to
    /// bounded drain mode, stopping once `MAX_DRAIN_BYTES` is exceeded.
    #[tokio::test]
    async fn test_body_reader_bounds_data_after_end_stream() {
        const CHUNK_SIZE: usize = 64 * 1024;
        const JUNK_TOTAL: usize = 4 * 1024 * 1024;

        let pulled = Arc::new(std::sync::atomic::AtomicUsize::new(0));

        // A valid END_STREAM envelope followed by 4 MiB of trailing junk.
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(Envelope::end_stream(Bytes::from_static(b"{}")).encode());
        for _ in 0..(JUNK_TOTAL / CHUNK_SIZE) {
            frames.push_back(Bytes::from(vec![0xAA_u8; CHUNK_SIZE]));
        }

        let body = CountingBody {
            frames,
            pulled: Arc::clone(&pulled),
        };

        let (mut request_stream, reader_task) = spawn_body_reader(
            body,
            DEFAULT_MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );

        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");

        // The handler-facing stream sees a clean end of stream: no messages,
        // no error. Trailing junk after END_STREAM must not surface to the
        // handler.
        assert!(
            request_stream.next().await.is_none(),
            "request stream must end cleanly after END_STREAM"
        );

        // The reader must stop pulling from the body shortly after the drain
        // limit instead of buffering the trailing data without bound.
        let pulled = pulled.load(std::sync::atomic::Ordering::Relaxed);
        let max_expected = MAX_DRAIN_BYTES + CHUNK_SIZE + crate::envelope::HEADER_SIZE + 2;
        assert!(
            pulled <= max_expected,
            "reader pulled {pulled} bytes after END_STREAM (expected at most \
             {max_expected}); trailing data is being buffered without bound"
        );
    }

    /// An END_STREAM envelope with no preceding messages (the typical
    /// "no client messages" request body) ends the request stream cleanly.
    #[tokio::test]
    async fn test_body_reader_end_stream_only() {
        let pulled = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let end_stream_frame = Envelope::end_stream(Bytes::from_static(b"{}")).encode();
        let frame_len = end_stream_frame.len();
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(end_stream_frame);

        let body = CountingBody {
            frames,
            pulled: Arc::clone(&pulled),
        };

        let (mut request_stream, reader_task) = spawn_body_reader(
            body,
            DEFAULT_MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );

        assert!(
            request_stream.next().await.is_none(),
            "request stream must end cleanly with no messages"
        );
        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");
        assert_eq!(
            pulled.load(std::sync::atomic::Ordering::Relaxed),
            frame_len,
            "the reader consumes exactly the END_STREAM frame"
        );
    }

    /// Trailing junk that arrives in the same body frame as the END_STREAM
    /// envelope is discarded without surfacing an error to the handler.
    #[tokio::test]
    async fn test_body_reader_junk_in_same_frame_as_end_stream() {
        let pulled = Arc::new(std::sync::atomic::AtomicUsize::new(0));

        let mut combined = Envelope::end_stream(Bytes::from_static(b"{}"))
            .encode()
            .to_vec();
        combined.extend_from_slice(&[0xAA_u8; 1024]);
        let frame = Bytes::from(combined);
        let frame_len = frame.len();
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(frame);

        let body = CountingBody {
            frames,
            pulled: Arc::clone(&pulled),
        };

        let (mut request_stream, reader_task) = spawn_body_reader(
            body,
            DEFAULT_MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );

        assert!(
            request_stream.next().await.is_none(),
            "trailing junk after END_STREAM must not surface to the handler"
        );
        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");
        assert_eq!(
            pulled.load(std::sync::atomic::Ordering::Relaxed),
            frame_len,
            "the reader consumes exactly the single combined frame"
        );
    }

    /// A data envelope followed by END_STREAM and EOF still delivers the
    /// message and then ends the request stream cleanly.
    #[tokio::test]
    async fn test_body_reader_message_then_end_stream() {
        let pulled = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let data_frame = Envelope::data(Bytes::from_static(b"hello")).encode();
        let end_stream_frame = Envelope::end_stream(Bytes::from_static(b"{}")).encode();
        let total_len = data_frame.len() + end_stream_frame.len();
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(data_frame);
        frames.push_back(end_stream_frame);

        let body = CountingBody {
            frames,
            pulled: Arc::clone(&pulled),
        };

        let (mut request_stream, reader_task) = spawn_body_reader(
            body,
            DEFAULT_MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );

        let first = request_stream
            .next()
            .await
            .expect("one message before END_STREAM")
            .expect("message decodes without error");
        assert_eq!(&first[..], b"hello");
        assert!(
            request_stream.next().await.is_none(),
            "request stream must end after END_STREAM"
        );

        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");
        assert_eq!(
            pulled.load(std::sync::atomic::Ordering::Relaxed),
            total_len,
            "the reader consumes exactly the two frames"
        );
    }

    /// When the handler drops the request stream, the reader stops decoding
    /// and drains the remaining body bounded by `MAX_DRAIN_BYTES` instead of
    /// buffering or forwarding it.
    #[tokio::test]
    async fn test_body_reader_bounds_data_after_receiver_dropped() {
        const CHUNK_SIZE: usize = 64 * 1024;
        const JUNK_TOTAL: usize = 4 * 1024 * 1024;

        let pulled = Arc::new(std::sync::atomic::AtomicUsize::new(0));

        // One decodable message followed by 4 MiB of junk.
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(Envelope::data(Bytes::from_static(b"hello")).encode());
        for _ in 0..(JUNK_TOTAL / CHUNK_SIZE) {
            frames.push_back(Bytes::from(vec![0xAA_u8; CHUNK_SIZE]));
        }

        let body = CountingBody {
            frames,
            pulled: Arc::clone(&pulled),
        };

        let (request_stream, reader_task) = spawn_body_reader(
            body,
            DEFAULT_MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );
        // The handler gives up on the request stream immediately.
        drop(request_stream);

        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");

        let pulled = pulled.load(std::sync::atomic::Ordering::Relaxed);
        let max_expected = MAX_DRAIN_BYTES + 2 * CHUNK_SIZE;
        assert!(
            pulled <= max_expected,
            "reader pulled {pulled} bytes after the receiver was dropped \
             (expected at most {max_expected})"
        );
    }

    /// A message that exceeds `max_message_size` surfaces a single error to
    /// the handler, and the remaining body is drained bounded by
    /// `MAX_DRAIN_BYTES`.
    #[tokio::test]
    async fn test_body_reader_bounds_data_after_decode_error() {
        const MAX_MESSAGE_SIZE: usize = 1024;
        const CHUNK_SIZE: usize = 64 * 1024;
        const JUNK_TOTAL: usize = 4 * 1024 * 1024;

        let pulled = Arc::new(std::sync::atomic::AtomicUsize::new(0));

        // An envelope header declaring a payload larger than the limit,
        // followed by 4 MiB of junk.
        let mut oversized = vec![0_u8; crate::envelope::HEADER_SIZE];
        oversized[1..].copy_from_slice(&4096_u32.to_be_bytes());
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(Bytes::from(oversized));
        for _ in 0..(JUNK_TOTAL / CHUNK_SIZE) {
            frames.push_back(Bytes::from(vec![0xAA_u8; CHUNK_SIZE]));
        }

        let body = CountingBody {
            frames,
            pulled: Arc::clone(&pulled),
        };

        let (mut request_stream, reader_task) = spawn_body_reader(
            body,
            MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );

        request_stream
            .next()
            .await
            .expect("an item must be delivered")
            .expect_err("the oversized message must surface as an error");
        assert!(
            request_stream.next().await.is_none(),
            "no further items after the decode error"
        );

        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");

        let pulled = pulled.load(std::sync::atomic::Ordering::Relaxed);
        let max_expected = MAX_DRAIN_BYTES + 2 * CHUNK_SIZE;
        assert!(
            pulled <= max_expected,
            "reader pulled {pulled} bytes after the decode error \
             (expected at most {max_expected})"
        );
    }

    /// Test body that yields a fixed sequence of data frames and then fails
    /// with a single transport-level body error.
    struct ErrorAfterFramesBody {
        frames: std::collections::VecDeque<Bytes>,
        errored: bool,
    }

    impl Body for ErrorAfterFramesBody {
        type Data = Bytes;
        type Error = std::io::Error;

        fn poll_frame(
            self: Pin<&mut Self>,
            _cx: &mut TaskContext<'_>,
        ) -> Poll<Option<Result<Frame<Self::Data>, Self::Error>>> {
            let this = self.get_mut();

            if let Some(data) = this.frames.pop_front() {
                return Poll::Ready(Some(Ok(Frame::data(data))));
            }

            if !this.errored {
                this.errored = true;
                return Poll::Ready(Some(Err(std::io::Error::new(
                    std::io::ErrorKind::UnexpectedEof,
                    "simulated body read failure",
                ))));
            }

            Poll::Ready(None)
        }
    }

    /// A request body that yields a valid streaming message and then fails at
    /// the transport level (while the reader is still decoding) must surface
    /// the failure to the handler as an internal error — not a clean EOF that
    /// is indistinguishable from a complete client stream.
    #[tokio::test]
    async fn test_body_reader_surfaces_body_error_while_decoding() {
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(Envelope::data(Bytes::from_static(b"hello")).encode());

        let body = ErrorAfterFramesBody {
            frames,
            errored: false,
        };

        let (mut request_stream, reader_task) = spawn_body_reader(
            body,
            DEFAULT_MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );

        let first = request_stream
            .next()
            .await
            .expect("one message before the body error")
            .expect("message decodes before the body error");
        assert_eq!(&first[..], b"hello");

        let err = request_stream
            .next()
            .await
            .expect("body error must be delivered")
            .expect_err("body error must not be converted to clean EOF");

        assert_eq!(err.code, crate::error::ErrorCode::Internal);
        assert!(
            err.message
                .as_deref()
                .unwrap_or_default()
                .contains("failed to read request body: simulated body read failure"),
            "unexpected error message: {:?}",
            err.message
        );

        assert!(
            request_stream.next().await.is_none(),
            "no further items after the body error"
        );

        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");
    }

    /// Once the reader has finished decoding (here: a clean END_STREAM has put
    /// it in drain mode), a subsequent transport-level body error is
    /// diagnostic-only — the handler already observed the terminal end of the
    /// stream and must not then receive a spurious error.
    #[tokio::test]
    async fn test_body_reader_body_error_after_end_stream_is_suppressed() {
        let mut frames = std::collections::VecDeque::new();
        frames.push_back(Envelope::end_stream(Bytes::from_static(b"{}")).encode());

        let body = ErrorAfterFramesBody {
            frames,
            errored: false,
        };

        let (mut request_stream, reader_task) = spawn_body_reader(
            body,
            DEFAULT_MAX_MESSAGE_SIZE,
            None,
            Arc::new(CompressionRegistry::new()),
        );

        // END_STREAM ended the stream cleanly; the body error that follows is
        // suppressed, so the handler sees a clean end with no error item.
        assert!(
            request_stream.next().await.is_none(),
            "a body error after END_STREAM must not surface to the handler"
        );

        reader_task
            .expect("tests run inside a tokio runtime")
            .await
            .expect("reader task must not panic");
    }
}
